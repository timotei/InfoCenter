#include <string.h>
#include <fstream.h>
 
int isVoc(char c)
{
 char voc[]="aeiouAEIOU";
 for (int i=0;i<strlen(voc);i++)
  if (voc[i]==c) return 1;
return 0;
}
void codifica(char c[100])
{
 ofstream fout("codifica.out");
 for (int i=0;i<strlen(c);i++)
 {
  if (isVoc(c[i]))
fout<<c[i]<<(char)(((int)c[i])+1);
  else fout<<c[i];
 }
 fout<<"stop";
 fout.close();
}
// Returneaza nr de vocale din sir;
int getNVoc(char c[100])
{
 int k=0; 
 for (int i=0;i<strlen(c);i++)
  if(isVoc(c[i])) k++;
 return k;
}
void afis(char a[100])
{
 for (int i=0;i<=strlen(a);i++)
  cout<<a[i];
 cout<<endl;
}
// Sterge din sir prima vocala care o intalneste;
void stergeVoc(char a[100])
{
 int sters=1;
 for (int i=0;i<strlen(a);i++)
  if (isVoc(a[i]) && (sters==1))
  {
	for (int j=i,k=i+1;k<strlen(a);j++,k++)
	  a[j]=a[k];
	 sters=0;
  }
 a[i-1]='\0';
}
 

   void afisFaraVoc(char c[100])
{
 char a[100];
 strcpy(a,c);
 for (int i=1;i<=getNVoc(c);i++)
 {
  stergeVoc(a);
  afis(a);
 }
}
void main()
{
 char c[100];
 cout<<"Dati text: ";
 cin.getline(c,100);
 codifica(c);
 afisFaraVoc(c);
}