#include<fstream.h>
int a[100][100],n,m;
int x[100];
void citire()
{
 int i,x,y;
 ifstream fin("graf1.in");
 fin>>n>>m;
 for (i=1;i<=m;i++)
 {
  fin>>x>>y;
  a[x][y]=a[y][x]=1;
 }
 fin.close();
}
void afisMat()
{
 cout<<"matrice adiacenta: ";
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void afis()
{
 for (int i=1;i<=4;i++)
  cout<<x[i]<<" ";
 cout<<endl;
}
int verif(int i)
{
 if (i>1 && !a[x[i-1]][x[i]]) return 0;

 for (int z=1;z<i;z++)
  for (int k=z+1;k<=i;k++)
   if (x[z]==x[k]) return 0;
 return 1;
}
void gen(int i)
{
 for (int j=1;j<=n;j++)
 {
  x[i]=j;
  if (verif(i))
   if (i==4) afis();
   else gen(i+1);
 }
}
void main()
{
 citire();
 afisMat();
 cout<<"lanturile elementare de lungime 3: "<<endl;
 gen(1);
}