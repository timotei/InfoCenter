#include<fstream.h>
int x[100]={0},n=0,banc[100]={0},plata=0;
void afis(int j)
{
  for (int i=1;i<=j;i++)
   if (x[i]!=0) cout<<banc[i]<<"*"<<x[i]<<" ";
  cout<<endl;
}
void gen(int i,int s)
{
 for (int j=0;j<=s/banc[i];j++)
 {
  x[i]=j;
  if (s==j*banc[i]) afis(i);
  else
  if(i<n) gen(i+1,s-j*banc[i]);
 }
}
void main()
{
 cout<<endl;
 ifstream fin("plata.in");

 fin>>plata>>n;
 for (int i=1;i<=n;i++)
  fin>>banc[i];
 fin.close();

 cout<<"Platim "<<plata<<": "<<endl;
 gen(1,plata);
}