#include<iostream.h>
#include<math.h>
int x[100]={0},sir[100]={0},n,v;
void afis()
{
 for (int i=1;i<=n;i++)
  cout<<sir[x[i]]<<" ";
 cout<<endl;
}
int verif(int i)
{
 for(int j=1;j<i;j++)
  if (x[i]==x[j]) return 0;
 if (i>1 && (abs(x[i]-x[i-1])<v))  return 0;
 return 1;
}
void gen(int i)
{
 for (int j=1;j<=n;j++)
 {
  x[i]=j;
  if(verif(i))
      if (i==n) afis();
      else gen(i+1);
 }
}
void main()
{
 cout<<"Dati n: "; cin>>n;
 cout<<"Dati v: "; cin>>v;
 for (int i=1;i<=n;i++)
  sir[i]=i;
 cout<<"Solutii: "<<endl;
 gen(1);
}