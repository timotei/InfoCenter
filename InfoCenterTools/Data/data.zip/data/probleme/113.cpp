#include<fstream.h>
int x[100],n;
int a[100][100],sec;
int lant()
{
 int i,j,ok=1,elem=1;
 for (i=1;i<sec;i++)
  {
   if (a[x[i]][x[i+1]]==0) ok=0;

   for (j=i+1;j<=sec;j++)
    if (x[i]==x[j]) elem=0;
  }

 if (elem) return 2;
 if (ok) return 1;
 return 0;
}
int ciclu()
{
 return 0;
}
void main()
{
 cout<<endl;
 int i=0,j,nr;
 ifstream fin("prob3.in");
 fin>>n;
 for (i=1;i<=n;i++)
  for (j=1;j<=n;j++)
   fin>>a[i][j];

 i=0;
 while(fin>>nr) x[++i]=nr;
 sec=i;

 fin.close();

 int l,c;
 l=lant();
 c=ciclu();

 cout<<"a) lant: "<< (l==1 || l==2 ?"Da":"Nu") <<endl;
 cout<<"b) lant elementar: "<< (l==2?"Da":"Nu") <<endl;
 cout<<"c) ciclu: "<< (c==1||c==2?"Da":"Nu") <<endl;
 cout<<"d) ciclu: elementar: "<<( c==2?"Da":"Nu") <<endl;
}