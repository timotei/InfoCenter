#include<fstream.h>
struct nod{
 int nr;
 nod *urm;
};
void add(nod *&v, int nr)
{
nod *p=new nod;
p->nr=nr;
p->urm=v;
v=p;
}
void afis(nod *v)
{
 while(v)
 { cout<<v->nr<<" "; v=v->urm;}
 cout<<endl;
}
void add2(nod *&v, int n)
{
 nod *q=new nod;
 q->nr=n;
 q->urm=v->urm;
 v->urm=q;
}
void addn(nod *&v, int n)
{
 nod *q,*p;
 if (v==NULL) { v=new nod; v->nr=n; v->urm=NULL; }
 // new
 else
  if (v->nr>n) { p=new nod; p->nr=n; p->urm=v; v=p;}
  else
  {
   p=v;
   while (p->urm && p->urm->nr<n) p=p->urm;
   if (p->urm) { q=new nod; q->nr=n; q->urm=p->urm; p->urm=q;}
   else { q=new nod; q->nr=n; q->urm=NULL; p->urm=q;}
  }
 // new
}
void main()
{
 cout<<endl;
 nod *v=NULL;
 int n;
 ifstream fin("dt.in");
 while (fin>>n)
 {
  addn(v,n);
  cout<<"Lista: "; afis(v);
 }
 cout<<"Lista: "; afis(v);
 fin.close();
}