#include<fstream.h>
int a[100][100],n,m;
int viz[100];
void citire()
{
 ifstream fin("graf.in");
 fin>>n>>m;
 int i,x,y;
 for (i=1;i<=m;i++)
 {
  fin>>x>>y;
  a[x][y]=a[y][x]=1;
 }
 fin.close();
}
void afisMat()
{
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void dfs(int nod)
{
 cout<<nod<<" ";
 viz[nod]=1;
 for (int i=1;i<=n;i++)
  if (a[nod][i] &&!viz[i])
   dfs(i);
}
void main()
{
 citire();
 afisMat();
 int i,j;
 for (i=1;i<=n;i++)
 {
  cout<<i<<": ";
  for (j=1;j<=n;j++) viz[j]=0;
  dfs(i);
  cout<<endl;
 }
}