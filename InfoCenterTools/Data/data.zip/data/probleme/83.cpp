#include<fstream.h>
int x[100];
int n;
void afis()
{
 for (int i=1;i<=n;i++)
  cout<<x[i]<<" ";
 cout<<endl;
}
int verif(int i)
{
 if (i>1)
 {
  if (x[i-1]%2==0 && x[i]%2!=0) return 0;
  if (x[i-1]%2!=0 && x[i]%2==0) return 0;
 }
 return 1;
}
void gen(int i)
{
 int j;
 for(j=1;j<=4;j++)
	{
	 x[i]=j;
	 if (verif(i)) if(i==n) afis();
	   else gen(i+1);

	}
}
void main()
{
cout<<"Dati n: "; cin>>n;
gen(1);
}

#include<iostream.h>
#include<conio.h>
void main(){
  int a,b,*p=&a,*q=&b,max;
  cin>>a>>b;
  if(*p>*q)cout<<*p;
  else     cout<<*q;
  cout<<max;
  getch();
}