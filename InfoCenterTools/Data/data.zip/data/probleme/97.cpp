#include<iostream.h>
#include<conio.h>
int n,x[100];
void afis()
{
 for(int i=1;i<=n;i++)
  {
    for(int j=1;j<=n;j++)
     if(x[i]==j) cout<<" 0 ";
     else cout<<" 1 ";
  cout<<endl;
 }
  cout<<endl;
}
int vf(int i)
{
 for(int j=1;j<i;j++)
  if(x[i]==x[j]) return 0;
  return 1;
}
void gen(int i)
{
 for(int j=1;j<=n;j++)
  {
   x[i]=j;
   if(vf(i)) if(i==n)  afis();
   else gen(i+1);
  }
}
void main()
{
 clrscr();
 cin>>n;
 gen(1);
}