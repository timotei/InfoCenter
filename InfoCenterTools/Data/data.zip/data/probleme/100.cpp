#include<fstream.h>
int lab[20][20],sol[20][20];
int n,m;
int di[] = {0, 0, 1, 0,-1},
    dj[] = {0, 1, 0,-1, 0};
ofstream fout("labir.out");
void afis()
{
 for(int i=1;i<=n;i++)
 {
  for (int j=1;j<=m;j++)
   fout<<sol[i][j]<<" ";
  fout<<endl;
 }
 fout<<endl;
}
void parcurge(int i,int j, int pas)
{
 int k,ii,jj;
 for(k=1;k<=4;k++)
 {
  ii=i+di[k];
  jj=j+dj[k];
  if (lab[ii][jj] && !sol[ii][jj])
  {
   sol[ii][jj] = pas;
   if (ii==1 || ii==n || jj==1 || jj==m)
     afis();
   else parcurge(ii,jj,pas+1);
   sol[ii][jj] = 0;
  }
 }
}
void main()
{
 int pi,pj;
 ifstream fin("labir.in");

 fin>>n>>m;
 fin>>pi>>pj;
 sol[pi][pj]=1;

 for(int i=1;i<=n;i++)
  for (int j=1;j<=m;j++)
   fin>>lab[i][j];

 parcurge(pi,pj,2);

 fin.close();
}