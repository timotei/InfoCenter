#include<fstream.h>
int x[100];
void afis(int i)
{
 for (int j=1;j<i;j++)
  cout<<x[j]<<"+";
 cout<<x[j];

 cout<<endl;
}
void gen(int i, int n)
{
 for (int j=1;j<=n;j++)
 {
  x[i]=j;
  if (j==n) afis(i);
   else gen(i+1,n-j);
 }
}
void main()
{
 int n=0;
 cout<<"Dati n: "; cin>>n;
 gen(1,n);
}