#include<fstream.h>
int n,x[100]={0},k;
void afis(int j)
{
 for (int i=1;i<=j;i++)
   cout<<x[i]<<" ";
 cout<<endl;
}
void gen(int i)
{
 for (int j=(x[i-1]+1);j<=(n+k);j++)
 {
  x[i]=j;
  if (x[i]==(n+k))
   afis(i);
  else gen(i+1);
 }
}
void main()
{
 cout<<"Dati n: "; cin>>n;
 cout<<"Dati k: "; cin>>k;
 x[1]=k;
 gen(2);
}