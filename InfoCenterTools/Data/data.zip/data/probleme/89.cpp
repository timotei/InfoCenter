#include<fstream.h>
struct cub{ int l; char cul; };
int x[100];
cub cubs[100];
int n=0,k=0;
void afis()
{
 for (int i=1;i<=k;i++)
  cout<<cubs[x[i]].l<<"-"<<cubs[x[i]].cul<<" ";
 cout<<endl;
}
int verif(int i)
{
 for(int j=1;j<i;j++)
  if (x[i]==x[j]) return 0;

 if (i>1)
 {
  if (cubs[x[i]].l > cubs[x[i-1]].l) return 0;
  if (cubs[x[i]].cul == cubs[x[i-1]].cul) return 0;
 }
 return 1;
}
void gen(int i)
{
 int j;
 for(j=1;j<=n;j++)
	{
	 x[i]=j;
	 if (verif(i)) if(i==k) afis();
		else gen(i+1);
	}
}
void main()
{
ifstream fin("date.in");
cout<<"Dati n: "; fin>>n;
cout<<"Dati k: "; fin>>k;
cout<<"Dati cuburi (lung,culoare=litera): \n";
for (int i=1;i<=n;i++)
{
  fin>>cubs[i].l;
  fin>>cubs[i].cul;
}
gen(1);
}