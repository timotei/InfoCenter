#include<fstream.h>
#include<values.h>
int n;
void creare(int a[100][2])
{
 int nr,i=1;
 ifstream fin("date.in");
 fin>>n;
 for(i=1;i<=n;i++)
 { fin>>nr; a[i][0]=nr; a[i][1]=i; }
 fin.close();
}
void afis(int a[100][2])
{
 for (int i=1;i<=n;i++)
  cout<<a[i][0]<<" ";
 cout<<endl;
}
void ordonare(int a[100][2])
{
 for (int i=1;i<=n;i++)
  for (int j=i;j<=n;j++)
   if (a[i][0]>a[j][0])
   {
    int aux=a[i][0];
    int aux2=a[i][1];
    a[i][0]=a[j][0]; a[i][1]=a[j][1];
    a[j][0]=aux; a[j][1]=aux2;
   }
}
void afisOptim(int a[100][2])
{
 cout<<"Optimi: ";
 int min=9999;
 ordonare(a);
 afis(a);
 for (int i=1;i<=n;i++)
  cout<<a[i][1]<<" ";
 cout<<endl;
}
void main()
{
 cout<<endl;
 int s[100][2]={0};
 creare(s);
 cout<<"Timpi: "; afis(s);
 afisOptim(s);
}