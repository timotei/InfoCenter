#include <iostream.h>
#include <values.h>
int x[100],n;
void inter(int st, int dr, int m)
{
 int a[100],b[100],i,j;
 for (i=st;i<=m;i++)
  a[i-st+1]=x[i];
 a[i-st+1]=MAXINT;

 for (i=m+1;i<=dr;i++)
  b[i-m]=x[i];
 b[i-m]=MAXINT;

 i=1,j=1;

 for (int k=st;k<=dr;k++)
  if (a[i]<b[j]) { x[k]=a[i]; i++; }
  else { x[k]=b[j]; j++; }
}
void ordonare(int st, int dr)
{
 if (st==dr) return;
 else
 {
  int m=(st+dr)/2;
  ordonare(st,m);
  ordonare(m+1,dr);
  inter(st,dr,m);
 }
}
void afis()
{
 for (int i=1;i<=n;i++)
  cout<<x[i]<<" ";
 cout<<endl;
}
void main()
{
 cout<<"Dati n: "; cin>>n;
 cout<<"Dati elem: ";
 for (int i=1;i<=n;i++)
  cin>>x[i];
 cout<<endl;
 afis();
 ordonare(1,n);
 afis();
}