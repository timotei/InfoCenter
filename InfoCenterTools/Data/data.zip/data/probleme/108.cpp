#include<fstream.h>
#include<string.h>
char car[20][20],sol[20][20];
int di[]={0,0,1,0,-1};
int dj[]={0,1,0,-1,0};
int st,n,m;
char cuv[100];
ofstream fout("careu.out");
void afis()
{
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=m;j++)
   fout<<sol[i][j]<<" ";
  fout<<endl;
 }
 fout<<endl;
}
void cauta(int i, int j,int poz)
{
 int k,ii,jj;
 for (k=1;k<=4;k++)
 {
  ii=i+di[k];
  jj=j+dj[k];
  if (car[ii][jj]==cuv[poz] && sol[ii][jj]==0)
  {
   sol[ii][jj]=car[ii][jj];
   if (poz<st) cauta(ii,jj,poz+1);
   else afis();
   sol[ii][jj]=0;
  }
 }
}
void main()
{

 ifstream fin("careu.in");
 fin>>n>>m;
 int i,j;
 for (i=1;i<=n;i++)
  for (j=1;j<=m;j++)
   fin>>car[i][j];
 fin>>cuv;
 st=strlen(cuv);
 for (i=1;i<=n;i++)
  for (j=1;j<=m;j++)
   if (car[i][j]==cuv[0])
   {
    sol[i][j]=car[i][j];
    cauta(i,j,1);
    sol[i][j]=0;
   }
 fin.close();
}