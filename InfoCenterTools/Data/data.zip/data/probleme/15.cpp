#include<iostream.h>
int distinct(long nr)
{
int a[10]={0};
while (nr)
{
 a[nr%10]++;
 nr=nr/10;
}
for (int i=0;i<=9;i++)
 if (a[i]>1) return 0;
return 1;
}
void main()
{
int a,b;
cout<<"Dati a: "; cin>>a;
cout<<"Dati b: "; cin>>b;
for (int i=a,k=0,cnt=0;i<=b;i++)
  if (k==10) {cout<<endl; k=1;}
  else
	if (distinct(i)) {cout<<i<<" "; cnt++; k++;}
if (cnt==0) cout<<"Nu sunt nr dist"<<endl;
}