#include<fstream.h>
int n,m,a[100][100];
int viz[100];
void citire()
{
 int x,y;
 ifstream fin("graf.in");
 fin>>n>>m;
 for (int i=1;i<=m;i++)
 {
  fin>>x>>y;
  a[x][y]=a[y][x]=1;
 }
 fin.close();
}
void afisMat()
{
 cout<<"Matrice de adiacenta: "<<endl;
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void dfs(int nod, int nrc)
{
 viz[nod]=nrc;

 for (int i=1;i<=n;i++)
  if (a[nod][i] && !viz[i])
   dfs(i,nrc);
}
void main()
{
 cout<<endl;
 int nrc=0,i,j;
 citire();
 afisMat();

 for (i=1;i<=n;i++)
  if (!viz[i])
  {
   nrc+=1;
   dfs(i,nrc);
  }

 cout<<"a) Componente conexe: "<<endl;
 for (i=1;i<=nrc;i++)
 {
  cout<<"Comp "<<i<<": ";

  for (j=1;j<=n;j++)
   if (viz[j]==i) cout<<j<<" ";

  cout<<endl;
 }

 cout<<"b) Muchii care ar putea fi adaugate: "<<endl;
 for (i=1;i<=n;i++)
 {
  for (j=1;j<=n;j++)
   if (viz[i]!=viz[j])
    cout<<i<<"-"<<j<<" ";
  cout<<endl;
 }
}