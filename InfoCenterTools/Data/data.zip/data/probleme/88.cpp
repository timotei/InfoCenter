#include<fstream.h>
#include<stdio.h>
int n=0,k=0;
int a[10][10]={0},x[100];
void afis()
{
 for (int i=1;i<=n;i++)
  cout<<x[i]<<" ";
 cout<<endl;
}
int verif(int i)
{
 for (int j=1;j<i;j++)
  if (a[i][j]==1 && x[i]==x[j]) return 0;
 return 1;
}
void gen(int i)
{
 for (int j=1;j<=k;j++)
  {
   x[i]=j;
   if (verif(i))
    if (i==n) afis();
    else gen(i+1);
  }
}
void main()
{
 cout<<"Dati n,k: "; cin>>n>>k;
 cout<<"Dati vecini: "<<endl;
 for (int i=1;i<=n;i++)
 {
  cout<<i<<":";
  int c=0;
  while(cin>>c)
   if (c!=13) a[i][c]=1;
   else continue;
  cout<<endl;
 }
 gen(1);
}