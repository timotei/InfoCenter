#include<fstream.h>
int a[100][100],n,m;
int l,viz[100];

void citire()
{
 int x,y,i;
 ifstream fin("graf1.in");
 fin>>n>>m;
 for (i=1;i<=m;i++)
 {
  fin>>x>>y;
  a[x][y]=a[y][x]=1;
 }
 fin.close();
}
void afisMat()
{
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}

void main()
{
 citire();
 afisMat();
 int grafhamil=1,i,j,gr;
 for (i=1;i<=n;i++)
 {
  gr=0;
  for (j=1;j<=n;j++)
   if (a[i][j]) gr+=1;
  if (gr<(n/2)) { grafhamil=0; break;}
 }

 if (grafhamil) cout<<"Graful este hamiltonian.";
 else cout<<"Graful nu este hamiltonian.";
 cout<<endl;
}