#include <iostream.h>
#include <math.h>
void main()
{
int a[50]={0},n;
int ucp=0,s=0;
cout<<"Dati n: "; cin>>n;
cout<<"Dati elemente: ";
for (int i=1;i<=n;i++)
 {
  cin>>a[i];
  if (a[i]%2==0) ucp++;
  s=s+a[i];
 }
cout<<"SiruL: ";
for (i=1;i<=n;i++)
 cout<<a[i]<<" ";
cout<<endl<<ucp<<" numere au ultima cifra para"<<endl;
cout<<"Suma: "<<s<<" | U.C. a sumei: "<<s%10<<endl;
cout<<"2 la n: "<<pow(2,n)<<endl;
long s2=0;
for (i=2;i<=9;i++)
 s2=s2+pow(i,s%10);
cout<<"Suma: "<<s2<<" | U.C.: "<<s2%10<<endl;
}