#include<fstream.h>
 
struct nod{
 float nr;
 nod *urm;
};
void add(nod *&v, float nr)
{
 nod *p=new nod;
 p->nr=nr;
 p->urm=v;
 v=p;
}
void afis(nod *v)
{
 while (v)
 { cout<<v->nr<<" "; v=v->urm; }
 cout<<endl;
}
float MedA(float n1, float n2)
{
 return (n1+n2)/2;
}
void insertMA(nod *&v)
{
 nod *p=v;
 while (p->urm)
 {
  float ma=MedA(p->nr,p->urm->nr);
  nod *q=new nod;
  q->nr=ma;
  q->urm=p->urm;
  p->urm=q;
  p=p->urm->urm;
 }
}
 

void main()
{
 nod *v=NULL;
 float nr;
 ifstream fin("what.in");
 while (fin>>nr)
   add(v,nr);
 cout<<"Stiva: ";afis(v);
 insertMA(v);
 cout<<"Stiva dupa inserare: "; afis(v);
 fin.close();
}