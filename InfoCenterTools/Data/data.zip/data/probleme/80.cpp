#include<fstream.h>
int x[100];
int n,k;
void cont()
{
 long nou=0;
 for(int i=1;i<=n;i++)
	nou=nou*10+x[i];
 long aux=nou;
 int ok=1;
 for(i=1;i<=n;i++)
	{
	 if(nou%k!=0) ok=0;
	 nou/=10;
	}
 if(ok==1) cout<<aux<<endl;
}
void gen(int i)
{
 int j;
 for(j=0;j<=9;j++)
	{
	 x[i]=j;
	 if(i==n) cont();
	   else gen(i+1);

	}
}
void main()
{
cin>>n>>k;
gen(1);
}