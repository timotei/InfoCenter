#include<fstream.h>
#include<values.h>
#include<conio.h>
struct nod {
  int nr;
  nod *urm;
};
void add(nod *v, int nr)
{
 nod *p=v,*q=new nod;
 while (nr>p->urm->nr) p=p->urm;

 q->nr=nr;
 q->urm=p->urm;
 p->urm=q;
}
void creare(nod *&v)
{
  v=new nod;
  nod *p=new nod;
  v->urm=p;
  p->nr=MAXINT;
  p->urm=NULL;
  ifstream fin("date.in");
  int nr;
  while (fin>>nr) add(v,nr);
  fin.close();
}
void afis(nod *v)
{
 nod *p=v;
 do
 {
  cout<<p->nr<<" ";
  p=p->urm;
 }while(p!=v);
 cout<<endl;
}
void makeCirculara(nod *&v)
{
 nod *l;
 l=v;
 v=v->urm;
 delete l;

 nod *p=v;
 while (p->urm->urm!=NULL) p=p->urm;
 l=p->urm->urm;
 p->urm=v;
 delete l;
}
void afisPerm(nod *v)
{
 cout<<endl;
 nod *q=v;
 int n=0;
 // NR Elemente lista.
 do{ n++; q=q->urm;} while(q!=v);

 for (int i=1;i<=n;i++)
 {
  nod *p=v,*z; int x=i;
  while(x>1) { p=p->urm; x--; }
  z=p;
  do{ cout<<z->nr<<" "; z=z->urm;} while(z!=p);
  cout<<endl;
 }
}
void main()
{
 clrscr();
 nod *v;
 creare(v);
 makeCirculara(v);
 cout<<"Stiva: "; afis(v);
 cout<<"Permutarile: "; afisPerm(v);
}