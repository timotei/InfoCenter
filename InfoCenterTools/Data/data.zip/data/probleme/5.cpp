#include <iostream.h>
void permutare(int k,long n)
{
int a[50]={0};
long aux=0,aux2=n;
int i=0,en=0;
while (aux2)
{ aux=aux*10+aux2%10; aux2=aux2/10;}
while (aux)
{ a[i]=aux%10; aux=aux/10; i++; }
en=i; i=k;
long nou=0;
for (;i<en;i++)
 nou=nou*10+a[i];
for (i=0;i<k;i++)
 nou=nou*10+a[i];
cout<<"Nou nr: "<<nou;
}
void main()
{
long n,k;
cout<<"Dati n: "; cin>>n;
cout<<"Dati k: "; cin>>k;
permutare(k,n);
}