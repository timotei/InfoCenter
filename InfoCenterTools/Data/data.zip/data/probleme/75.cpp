#include<iostream.h>
int x[100],k,sol=0;
char sir[100]={' ', 'A', 'M' };
void afis()
{
 for (int i=1;i<=k;i++)
  cout<<sir[x[i]]<<" ";
 cout<<endl;
 sol++;
}
int verif(int i)
{
 for (int j=1;j<=i;j++)
  if (sir[x[j]]=='A' && sir[x[j+1]]=='A') return 0;
 return 1;
}
void gen(int i)
{
 for (int j=1;j<=2;j++)
  {
   x[i]=j;
   if (verif(i))
    if (i==k) afis();
   else gen(i+1);
  }
}
void main()
{
 cout<<"Dati k: "; cin>>k;
 gen(1);
 cout<<"Total solutii: "<<sol<<endl;
}