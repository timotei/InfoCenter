#include<fstream.h>
#include<iomanip.h>
int ph[20][20],sol[20][20];
int n,m,x,y,max,maxp;
int di[] = {0,1,-1,0, 0},
    dj[] = {0,0, 0,1,-1};
ofstream fout("bebel.out");
void afis(int pas)
{
 int mp=0;
 fout<<"Camera: "<<pas<<endl;
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=m;j++)
   if (sol[i][j]==pas)
    { fout<<sol[i][j]<<" "; mp+=1; }
   else fout<<"0 ";
  fout<<endl;
 }
 fout<<endl;
 if (maxp<mp) { maxp=mp; max=pas; }
}
void caut(int i,int j, int pas)
{
 int k,ii,jj;
 for (k=1;k<=4;k++)
 {
  ii=i+di[k];
  jj=j+dj[k];
  if (ph[ii][jj]==0 && !sol[ii][jj])
  {
   sol[ii][jj]=pas;
   caut(ii,jj,pas);
  }
 }
}
void fuge(int i, int j)
{
 int k,ii,jj;
 for (k=1;k<=4;k++)
 {
  ii=i+di[k];
  jj=j+dj[k];
  if ( (ph[ii][jj]==0 || ph[ii][jj]==2)&& !sol[ii][jj])
  {
   sol[ii][jj]=5;
   fuge(ii,jj);
  }
 }

}
void main()
{
 int pas,i,j;
 ifstream fin("apart.in");
 fin>>n>>m;
 fin>>x>>y;
 for (i=1;i<=n;i++)
  for (j=1;j<=m;j++)
   fin>>ph[i][j];
 pas=0;

 for (i=1;i<=n;i++)
  for (j=1;j<=m;j++)
   if (ph[i][j]==0 && !sol[i][j])
   {
    pas++;
    caut(i,j,pas);
    afis(pas);
   }
 cout<<"a) Camere: "<<pas<<endl;
 cout<<"b) Cea mai mare camera: "<<max<<"("<<maxp<<"mp)"<<endl;
 for (i=1;i<=n;i++)
  for(j=1;j<=m;j++)
   {
    sol[i][j]=0;
   }
 sol[i][j]=5;
 fuge(x,y);
 cout<<"c) Solutie: "<<endl;
 for (i=1;i<=n;i++)
 {
  for (j=1;j<=m;j++)
   if (sol[i][j]==5) cout<<"x ";
   else if (j==1 || j==m) cout<<"|";
   else if (i==1 || i==n) cout<<"--";
   else cout<<"  ";
  cout<<endl;
 }
 cout<<endl;
}