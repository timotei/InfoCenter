#include<fstream.h>
int a[100][100],n,m;
int viz[100];
void citire()
{
 ifstream fin("graf.in");
 fin>>n>>m;
 int x,y,i;
 for (i=1;i<=m;i++)
 {
  fin>>x>>y;
  a[x][y]=1;
 }
 fin.close();
}
void afisMat()
{
  cout<<"Matricea: "<<endl;
  for (int i=1;i<=n;i++)
  {
   for (int j=1;j<=n;j++)
    cout<<a[i][j]<<" ";
   cout<<endl;
  }
  cout<<endl;
}
void dfs(int nod, int nrc)
{
 viz[nod]=nrc;
 for (int i=1;i<=n;i++)
  if (a[nod][i] && !viz[i])
   dfs(i,nrc);
}
void main()
{
  citire();
  afisMat();
  int nrc=0,x,i;
  cout<<"Dati x: "; cin>>x;
  for (i=1;i<=n;i++)
   if (!viz[i])
   {
    nrc++;
    dfs(i,nrc);
   }
  cout<<"Varfurile care sunt in comp conexa a lui x("<<viz[x]<<") sunt: ";
  for (i=1;i<=n;i++)
   if (viz[i]==viz[x]) cout<<i<<" ";
  cout<<endl;
}