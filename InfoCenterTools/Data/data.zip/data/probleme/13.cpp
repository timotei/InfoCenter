#include <fstream.h>
int includ(long n, long x[50], int k1)
{
 for (int i=1;i<=k1;i++)
  if (n==x[i]) return 1;
return 0;
}
void main()
{
 long n1,n2;
 int k1,k2;
 int i=1;
 long x[50], y[50];
 ifstream f1("f1.txt");
 ifstream f2("f2.txt");
 ofstream f3("f3.txt");
 while (f1>>n1)
  {x[i]=n1; i++;}
 k1=i; i=1;
 while (f2>>n2)
  {y[i]=n2; i++;}
 k2=i;
 for (i=1;i<=k1;i++)
  if (includ(x[i],y,k2))
   f3<<x[i]<<" ";
 f1.close();
 f2.close();
 f3.close();
}