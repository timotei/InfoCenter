#include<fstream.h>
int a[100][100],b[100][100],n,m;
int x[100];
void citire()
{
 ifstream fin("graf.in");
 fin>>n>>m;
 int x,y,i;
 for (i=1;i<=m;i++)
 {
  fin>>x>>y;
  a[x][y]=1;
  b[x][y]=1;
 }
 fin.close();
}
void afisMat()
{
  cout<<"Matricea: "<<endl;
  for (int i=1;i<=n;i++)
  {
   for (int j=1;j<=n;j++)
    cout<<a[i][j]<<" ";
   cout<<endl;
  }
  cout<<endl;
}

int min(int a, int b)
{
 if (a<b) return a;
 return b;
}
void transforma()
{
 for (int k=1;k<=n;k++)
  for (int i=1;i<=n;i++)
   if (i!=k)
    for (int j=1;j<=n;j++)
     if (j!=k)
      if (b[i][j]==0)
       b[i][j]=min(b[i][k],b[k][j]);
}
void afis(int i)
{
 for (int j=1;j<=i;j++)
  cout<<x[j]<<" ";
 cout<<endl;
}
int verif(int i)
{
 if (!a[x[i-1]][x[i]]) return 0;

 for (int j=1;j<i;j++)
  if (x[j]==x[i]) return 0;
 return 1;
}
void gen(int i)
{
  for (int j=1;j<=n;j++)
  {
   x[i]=j;
   if(verif(i)) { if (i<n) gen(i+1); afis(i); }

  }  
}
void main()
{
  citire();
  afisMat();
  transforma();
  int z;
  cout<<"Dati x: "; cin>>z;
  x[1]=z;
  gen(2);

}