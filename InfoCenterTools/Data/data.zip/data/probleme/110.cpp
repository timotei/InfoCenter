#include<fstream.h>
int a[50][50],n,m;
int c[100],viz[100],cnt,ultim;
void citire()
{
 ifstream fin("bfs1.in");
 fin>>n>>m;
 for (int i=1;i<=m;i++)
 {
  int x,y;
  fin>>x>>y;
  a[x][y]=a[y][x]=1;
 }
 fin.close();
}
void afis()
{
 cout<<"Mat de adiacenta: "<<endl;
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void bfs(int nod)
{
  c[1]=nod; viz[nod]=1; ultim=cnt=1;
  int k;
  while(cnt<=ultim)
  {
   k=c[cnt];
   for (int i=1;i<=n;i++)
    if (a[k][i] && !viz[i])
     {
      c[++ultim]=i;
      viz[i]=1;
     }
    cnt++;
  }
}
void main()
{
  int nod;
  citire();
  afis();

  cout<<"Dati nod: "; cin>>nod;
  cout<<"Parcurgere din "<<nod<<": ";
  bfs(nod);
  for (int i=1;i<=ultim;i++)
   cout<<c[i]<<" ";
  cout<<endl;
}