#include<fstream.h>
int n,m;
int cnt=0;
int aux[100],max;
int x[100];
int viz[100];
int a[100][100];
int np=1;
void afis(int i)
{
 for(int j=1;j<=i;j++)
  cout<<x[j]<<" ";
 cout<<endl;
}
int verif(int i)
{
 for(int j=1;j<i;j++)
  if(x[j]==x[i]) return 0;
 return 1;
}
void drum(int i)
{
 for(int j=1;j<=n;j++)
  if(a[x[i-1]][j]==1||i==1)
   {
    x[i]=j;
    if(verif(i))
    {
    if(i>1) {cnt++; afis(i);
             if(i>max)
                  {
                   max=i;
                   for(int p=1;p<=i;p++)
                     aux[p]=x[p];
                  }

            }
    if(i<n) drum(i+1);
    }
   }
}
void parc(int i)
{
 int j;
 for(j=1;j<=n;j++)

  if(a[i][j]&&!viz[j])
   {
    viz[j]=np;
    parc(j);
   }
}
int gradi(int i,int j)
{
 if(j==n) return 0;
 else
 {
  if(a[i][j]==1) return 1+gradi(i,j+1);
    else return gradi(i,j+1);
 }
}
int grade(int i,int j)
{
 if(j==n) return 0;
 else
  {
   if(a[j][i]==1) return 1+grade(i,j+1);
    else return grade(i,j+1);
  }
}
void main()
{
int x,y;
ifstream f("date.in");
f>>n>>m;
while(m)
{
 m--;
 f>>x>>y;
 a[x][y]=1;
}
drum(1);
cout<<"sunt "<<cnt<<" drumuri"<<endl;
cout<<"drumul maxim e:";
for(int i=1;i<=max;i++)
 cout<<aux[i]<<" ";
cout<<endl;
for(i=1;i<=n;i++)
 {
  if(!viz[i])
   {
    viz[i]=np;
    parc(i);
    np++;
   }
 }
cout<<"comp conexe sunt:";
for(i=1;i<np;i++)
 {
  cout<<endl;
  for(int j=1;j<=n;j++)
   if(viz[j]==i) cout<<j<<" ";
 }
cout<<endl;
for(i=1;i<=n;i++)
 {
  cout<<i<<":";
  cout<<gradi(i,1)<<" ";
  cout<<grade(i,1)<<" ";
  cout<<endl;
 }
 int xi;
 cout<<"dati xi:";
 cin>>xi;
 cout<<"nodurile din aceeasi comp conexa cu xi";
 for(i=1;i<=n;i++)
  if(viz[i]==viz[xi]) cout<<i<<" ";
 for(i=1;i<=n;i++)
  viz[i]=0;
 np=1;
 cout<<endl;
 cout<<"din xi se poate ajunge in:";
 parc(xi);
 for(i=1;i<=n;i++)
  if(viz[i]==1) cout<<i<<" ";
}