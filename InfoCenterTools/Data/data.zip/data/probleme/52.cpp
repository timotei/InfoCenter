#include<fstream.h>
#include<conio.h>
#include<string.h>
struct nod{
  int n;
  nod *ant;
  nod *urm;
};
void add(nod *&v, nod *&u, int n)
{
 nod *p=new nod;
 p->n=n;
 p->urm=NULL;
 p->ant=u;
 if(v==NULL) v=p;
 else u->urm=p;
 u=p;
}
void creare(nod *&v, nod *&u, char path[])
{
 ifstream fin(path);
 int n;
 while(fin>>n)
  add(v,u,n);
 fin.close();
}
void afis(nod *v)
{
  nod *p=v;
  if(p==NULL) return;
  while(p) { cout<<p->n; p=p->urm; }
  cout<<endl;
}
int calcS2(int k,int k2, int &ps)
{
  int r=k+k2;
  if (ps!=0) { r=r+ps; ps=0; }
  if (r>=10) { r=r-10; ps++;}
  return r;
}
void calcSuma(nod *v, nod *v2)
{
 int nr[200]={0},n=0;
 nod *p=v,*p1=v2;
 // ps-> resul de la adunare.
 int i=0,ps=0;
 while (p && p1)
 {
  nr[i]=calcS2(p->n,p1->n,ps); i++;
  p=p->ant;
  p1=p1->ant;
 }
 // ce a mai ramas din p1
 while(p1)
 {
  nr[i]=calcS2(p1->n,0,ps); i++;
  p1=p1->ant;
 }
 // ce a mai ramas din p
 while(p)
 {
  nr[i]=calcS2(p->n,0,ps); i++;
  p=p->ant;
 }
 n=i-1;
 // afis numar
 for (int j=n;j>=0;j--)
  cout<<(int)nr[j];
 cout<<endl;
}
int calcP2(int k,int k2, int &ps)
{
  int r=k*k2;
  if (ps!=0) { r=r+ps; ps=0; }
  if (r>=10) { r=r-10; ps++;}
  return r;
}
void calcProd(nod *v, nod *v2)
{
 int nr[200]={0},n=0,i=0,ps=0,st=0;
 nod *p,*p1=v2;
 while(p1)
 {
  p=v;
  int pr=p1->n;
  while(p)
  {

   p=p->ant;
  }
  p1=p1->ant; st++;
 }
 n=i-1;
 // afis numar
 for (int j=n;j>=0;j--)
  cout<<(int)nr[j];
 cout<<endl;
}
void main()
{
// clrscr();
cout<<endl;
 nod *v=NULL,*v2=NULL;
 nod *u=NULL,*u2=NULL;
 creare(v,u,"TIMO.IN");
 creare(v2,u2,"TIMO2.IN");
 cout<<"1: "; afis(v);
 cout<<"2: "; afis(v2);
 cout<<"Suma: "; calcSuma(u,u2);
}