#include<fstream.h>
#include<conio.h>
struct nod{int nr;nod *urm;};
void add(nod *&v, nod *&pr, int nr)
{
 nod *p=new nod; p->nr=nr;
 p->urm=NULL;if (v==NULL) v=p;
  else pr->urm=p;
 pr=p;
}
void afis(nod *v)
{
 while (v){cout<<v->nr<<" "; v=v->urm; }
 cout<<endl;
}
void creare(nod *&v, char path[10])
{
 ifstream fin(path); int nr;
 nod *pr=NULL;
 while (fin>>nr) add(v,pr,nr);
 fin.close();
}
int exist(nod *v, int nr)
{
 int i=0;
 while (v){if(v->nr==nr) i++; v=v->urm; }
 return i;
}
int isMultime(nod *v)
{
 while (v){ if (exist(v,v->nr)>1) return 0; v=v->urm; }
 return 1;
}
void creareMult(nod *&v)
{
 nod *p=NULL,*pr=NULL,*aux=v;
 while (v)
 {
  if (exist(aux,v->nr)==1) add(p,pr,v->nr);
  v=v->urm;}
 v=p;
}
void reuniune(nod *v, nod *v2, nod *&out)
{
nod *pr=NULL;
while (v) { if (exist(out,v->nr)==0) add(out,pr,v->nr); v=v->urm; }
while (v2) {if (exist(out,v2->nr)==0) add(out,pr,v2->nr); v2=v2->urm; }
}
void intersectie(nod *v, nod *v2, nod *&out)
{
 nod *pr=NULL,*a1=v;
 while (v) {if (exist(v2,v->nr)>0)
    if (exist(out,v->nr)==0)
      add(out,pr,v->nr);
   v=v->urm;
 }
 while (v2) {if (exist(a1,v->nr)>0)
    if (exist(out,v2->nr)==0)
      add(out,pr,v2->nr);
   v2=v2->urm;
 }
}
void diferenta(nod *v, nod *v2, nod *&out)
{
nod *pr=NULL; while (v)
 {
  if (exist(v2,v->nr)==0) add(out,pr,v->nr);
  v=v->urm;
 }
}
void main()
{
clrscr();
nod *v=NULL, *v2=NULL, *v3=NULL, *v4=NULL, *v5=NULL;
creare(v,"f1.txt");
creare(v2,"f2.txt");
cout<<"v: "; afis(v);
cout<<"v2: "; afis(v2);
if (!isMultime(v)) {creareMult(v); cout<<"v nou: "; afis(v);}
if (!isMultime(v2)) {creareMult(v2);cout<<"v2 nou: "; afis(v2);}
reuniune(v,v2,v3);
cout<<"reuni: "; afis(v3);
intersectie(v,v2,v4);
cout<<"interse: "; afis(v4);
diferenta(v,v2,v5);
cout<<"dif: "; afis(v5);
}