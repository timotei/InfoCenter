#include<iostream.h>
int isPrim(int nr)
{
 for (int i=2;i<=nr/2;i++)
  if (nr%i==0) return 0;
 return 1;
}
void afisNrPr(int k)
{
 for (int i=2,j=1;j<k;i++)
  if (isPrim(i)) {cout<<i<<" "; j++; }
 cout<<endl;
}
void main()
{ int n,a,b,s=0,k;
 cout<<"Dati n: "; cin>>n;
 for (int i=2;i<n;i++)
  if (isPrim(i)) cout<<i<<" ";
 cout<<endl<<"Dati k: "; cin>>k; i=1;
 afisNrPr(k);
 cout<<"Dati a: "; cin>>a;
 cout<<"Dati b: "; cin>>b;
 for (i=a;i<=b;i++)
  if (isPrim(i)==1) s=s+i;
 cout<<"Suma: "<<s<<endl;
 for (i=2;i<n;i++)
  for (int j=i+1;j<=n;j++)
   if (isPrim(i)&&isPrim(j)&&(j-i==2))
    cout<<i<<"-"<<j<<" ";
 cout<<endl;
}