#include<fstream.h>
#include<iomanip.h>
int pad[20][20],sol[20][20],min[20][20],minp=32000;
int n,m;
int di[] = {0, 0, 1, 0,-1},
    dj[] = {0, 1, 0,-1, 0};
ofstream fout("scuf.out");
void afis(int flori)
{
 sol[1][1]=1;
 for(int i=1;i<=n;i++)
 {
  for (int j=1;j<=m;j++)
   fout<<setw(2)<<sol[i][j]<<" ";
  fout<<endl;
 }
 fout<<"Flori: "<<flori<<endl;
 fout<<endl;

 if (sol[n][m]<minp)
 {
  for (int i=1;i<=n;i++)
   for (int j=1;j<=m;j++)
    min[i][j]=sol[i][j];
  minp = sol[n][m];
 }

}
void parcurge(int i,int j, int pas, int fl)
{
 int k,s,ii,jj;
 for(k=1;k<=4;k++)
 {
  ii=i+di[k];
  jj=j+dj[k];
  if ((pad[ii][jj]==1 || pad[ii][jj]==3) && !sol[ii][jj])
  {
   sol[ii][jj]=pas;
   if (pad[ii][jj]==1) s=fl+1;
   else s=fl;

   if (ii==n&&jj==m) afis(s);
   else parcurge(ii,jj,pas+1,s);

   sol[ii][jj]=0;
  }
 }
}
void umple(int x, int y)
{
 pad[x][y]=4;
 pad[x][y+1]=4;
 pad[x][y-1]=4;
 pad[x+1][y]=4;
 pad[x-1][y]=4;
 pad[x+1][y+1]=4;
 pad[x-1][y-1]=4;
 pad[x-1][y+1]=4;
}
void main()
{
 int x,y,i,j;
 ifstream fin("scuf.in");
 fin>>n>>m;
 fin>>x>>y;

 for(i=1;i<=n;i++)
  for (j=1;j<=m;j++)
   fin>>pad[i][j];
 umple(x,y);
 parcurge(1,1,2,0);
 fout<<"Drum minim: "<<endl;
 for (i=1;i<=n;i++)
 {
  for (j=1;j<=m;j++)
   fout<<setw(2)<<min[i][j]<<" ";
  fout<<endl;
 }
 fin.close();
}