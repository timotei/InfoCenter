#include<fstream.h>
struct nod{
 int nr;
 nod *urm;
};
void add(nod *&v, int nr)
{
nod *p=new nod;
p->nr=nr;
p->urm=v;
v=p;
}
void creare(nod *&v)
{
 int nr;
 ifstream fin("date.in");
 while (fin>>nr)
   add(v,nr);
 fin.close();
}
void afis(nod *v)
{
 while(v)
 { cout<<v->nr<<" "; v=v->urm;}
 cout<<endl;
}
void add2(nod *&v, int n)
{
 nod *q=new nod;
 q->nr=n;
 q->urm=v->urm;
 v->urm=q;
}
void addn(nod *&v, int n)
{
 nod *p=v;
 while (p)
 {
  if (n>=p->urm->nr)
  {
   add2(p,n);
   return;
  }
  p=p->urm;
 }
}
void main()
{
 cout<<endl;
 nod *v=NULL;
 int n;
 creare(v);
 cout<<"Lista: "; afis(v);
 cout<<"Dati n: "; cin>>n;
 addn(v,n);
 cout<<"Lista: "; afis(v);
}