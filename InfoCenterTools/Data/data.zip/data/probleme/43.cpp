#include<fstream.h>
struct nod {
  int nr;
  int fr;
  nod *urm;
};
int verSiModifica(nod *&v, int nr)
{
 nod *p=v;
 while(p)
 { if (p->nr==nr) {p->fr++; return 1;} p=p->urm; }
 return 0;
}
void addN(nod *&v, int nr)
{
  if (v==NULL){ v=new nod; v->nr=nr; v->fr=1; v->urm=NULL; }
  else
  if (!verSiModifica(v,nr))
	if (v->nr>nr) { nod *p=new nod; p->nr=nr; p->fr=1;p->urm=v; v=p;}
	else
	{
	 nod *p=v,*q;
	 while (p->urm && p->urm->nr<nr) p=p->urm;
	 if(p->urm) { q=new nod; q->nr=nr; q->fr=1; q->urm=p->urm; p->urm=q;}
	 else { q=new nod; q->nr=nr; q->fr=1; q->urm=NULL; p->urm=q;}
	}
}
void creare(nod *&v)
{
 int nr;
 ifstream fin("dt.in");
 cout<<"Nrcit: ";
 while (fin>>nr)
 {cout<<nr<<" "; addN(v,nr);}
 fin.close();
 cout<<endl;
}
void afis(nod *v)
{
 while (v) { cout<<v->nr<<"-"<<v->fr<<" "; v=v->urm; }
 cout<<endl;
}
void main()
{
 cout<<endl;
 nod *v=NULL;
 creare(v);
 cout<<"Stiva: "; afis(v);
}