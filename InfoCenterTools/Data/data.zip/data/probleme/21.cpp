#include<iostream.h>
#include<conio.h>
#include<stdlib.h>
struct nod{
int nr;
nod *urm;
};
void add(nod *&v, int a)
{
 nod *p=new nod; p->nr=a; p->urm=v; v=p;
}
void afis(nod *v)
{
 cout<<"Stiva este: ";
 while (v) {cout<<v->nr<<" "; v=v->urm;}
 cout<<endl;
}
int calcPuncte(nod *v)
{
 if (v) return v->nr+calcPuncte(v->urm);
 return 0;
}
void main()
{
 clrscr(); randomize();
 cout<<"Se arunca... "<<endl;
 nod *v=NULL, *v2=NULL; int nr=0,a1=0,a2=0;
 do { nr=random(6)+1; add(v,nr); a1++; }
 while (nr!=6);
 nr=0;
 do
 {
  nr=random(6)+1;
  add(v2,nr);
  a2++;
 }
 while (nr!=6);
 afis(v);
 afis(v2);
 cout<<"Aruncari: 1-> "<<a1<<endl<<"2-> "<<a2<<endl;
 int k1=calcPuncte(v);
 int k2=calcPuncte(v2);
 cout<<"Puncte: 1="<<k1<<" 2="<<k2<<" ";
 if (k1>k2) cout<<"Castigator 1!"<<endl;
  else cout<<"Castigator 2!"<<endl;
}