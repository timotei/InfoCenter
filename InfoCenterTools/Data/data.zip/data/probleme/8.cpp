#include <iostream.h>
#include <conio.h>
 
void cit(long x[], long n, int i)
{
 if(i<=n) {cin>>x[i]; cit(x,n,i+1);}
}
int nrcif(long a)
{
 if (a) return 1+nrcif(a/10);
return 0;
}
long sumnr(long x[], long n, int i)
{
  if (i<=n) 
return  nrcif(x[i])+sumnr(x,n,i+1);
 return 0;
}
int valOri(long x[], long n, int i, long val)
{
if (i<=n)
 {
  if (val==x[i]) 
return 1+valOri(x,n,i+1,val);
  else return valOri(x,n,i+1,val);
 }
return 0;
}
long getMax(long x[], long n, int i)
{
if (i>n) return 0;
else {
  if (x[i]>getMax(x,n,i+1)) return x[i];
  else return getMax(x,n,i+1);
 }
}
long Invers(long nr, long inv)
{
if (nr)
 return Invers(nr/10, inv*10+nr%10);

return 0;
}
long valInvers(long x[], long n)
{
 long max = getMax(x,n,1);

 return Invers(max,0);
}
void afisSirInvers(long x[50], long n, long i)
{
if (i>0) {cout<<x[i]<<" "; afisSirInvers(x,n,i-1); }
cout<<endl;
}
 
void main()
{
clrscr();
long x[50]={0}, n;
cout<<"Dati n: "; cin>>n;
cout<<"Dati elem: "; cit(x,n,1);
cout<<"Suma nr: "<<sumnr(x,n,1)<<endl;
cout<<"Dati val: ";
long val; cin>>val;
cout<<"val se gaseste in sir de "<<valOri(x,n,1,val)<<endl;
cout<<"val invers: "<<valInvers(x,n)<<endl;
cout<<"Sir invers: "<<endl;
afisSirInvers(x,n,n);
}