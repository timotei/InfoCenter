#include<fstream.h>
double x[100],k;
double cauta(int st, int dr)
{
 if (st==dr) return -1;
 else
 {
  int m=(st+dr)/2;
  if(x[m]==k) return m;
  else
   if (x[m]<k) return cauta(m+1,dr);
   else return cauta(st,m-1);
 }
}
void main()
{
 int i=1,n;
 double val;
 ifstream fin("date.in");
 fin>>n;
 for(i=1;i<=n;i++)
  fin>>x[i];
 cout<<"Dati valoare: "; cin>>k;
 cout<<"Prod: "<<cauta(1,n)<<endl;
 fin.close();
}