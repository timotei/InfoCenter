#include<fstream.h>
#include<conio.h>
#include<string.h>
struct nod{
  char nm[30];
  int cls;
  nod *ant;
  nod *urm;
};
void add(nod *v, char nm[], int cls)
{
 nod *p=v;
 while(strcmp(p->urm->nm,nm)<0) p=p->urm;

 nod *q=new nod;
 strcpy(q->nm,nm);
 q->cls=cls;
 q->urm=p->urm;
 q->ant=p;
 p->urm->ant=q;
 p->urm=q;
}
void creare(nod *&v)
{
 v=new nod;
 nod *p=new nod;

 v->urm=p;
 v->ant=NULL;

 strcpy(p->nm,"zzzzzzzz");
 p->urm=NULL;
 p->ant=v;

 ifstream fin("timo.in");
 int nr; char nm[30];
 while(fin>>nm) { fin>>nr; add(v,nm,nr); }
 fin.close();
}
void afis(nod *v)
{
  nod *p=v->urm;
  cout<<"Lista: "<<endl;
  while(p->urm) { cout<<p->nm<<" "<<p->cls<<endl; p=p->urm; }
  cout<<endl;
}
void afisClasa(nod *v, int x)
{
 nod *p=v->urm;
 cout<<"Elevi din clasa "<<x<<": "<<endl;
 while(p->urm)
 {
  if (p->cls==x) cout<<p->nm<<endl;
  p=p->urm;
 }
}
void main()
{
 clrscr();
 nod *v;
 creare(v);
 afis(v);
 int x;
 cout<<"Dati clasa: "; cin>>x;
 afisClasa(v,x);
}