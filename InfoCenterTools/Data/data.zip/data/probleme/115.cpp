#include<fstream.h>
int n;
int con[100],nrc;
void citire()
{
 int m;
 ifstream fin("graf.in");
 fin>>n>>m;
 int x,y,min,max,i,j;
 for (i=1;i<=n;i++) con[i]=i;
 for (i=1;i<=m;i++)
 {
  fin>>x>>y;

  if (con[x]<con[y]) { min=con[x]; max=con[y]; }
  else     { min=con[y]; max=con[x]; }

  if (nrc<max) nrc=max;

  for (j=1;j<=n;j++)
   if (con[j]==max) con[j]=min;
 }

}
void main()
{
 citire();
 int k,ncc;
 cout<<"Comp Conexe: "<<endl;
 for (int i=1;i<=n;i++)
 {
  k=0;
  for (int j=1;j<=n;j++)
   if (con[j]==i){ cout<<j<<" "; k=1; }
  if (k) { cout<<endl;ncc++; }
 }
}