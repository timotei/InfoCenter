#include<fstream.h>
int a[100][100],n,m;
int l,x[100],maxl,max[100];

void citire()
{
 int x,y,i;
 ifstream fin("graf1.in");
 fin>>n>>m;
 for (i=1;i<=m;i++)
 {
  fin>>x>>y;
  a[x][y]=a[y][x]=1;
 }
 fin.close();
}
void afisMat()
{
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void afisLant()
{
 for (int i=1;i<=maxl;i++)
  cout<<max[i]<<" ";
 cout<<endl;
}
int verif(int i)
{
 if (i>1 && !a[x[i-1]][x[i]]) return 0;

 for (int z=1;z<i;z++)
  for (int k=z+1;k<=i;k++)
   if (x[z]==x[k]) return 0;
 return 1;
}
void gen(int i)
{
 for (int j=1;j<=n;j++)
 {
  x[i]=j;
  if (verif(i))
   if (i>maxl)
   {
    maxl=i;
    for (int k=1;k<=maxl;k++)
     max[k]=x[k];
   }
   else gen(i+1);
 }
}

void main()
{
 citire();
 afisMat();
 cout<<"Cel mai lung lant elementar: ";
 gen(1);
 afisLant();
}