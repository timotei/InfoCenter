#include<iostream.h>
int sumcif(int nr)
{ int s=0;
  while(nr)
  { s=s+nr%10;nr=nr/10; }
  return s;
}
int maxcif(int nr)
{ int max=0;
 while (nr)
 { if (nr%10>max) max=nr%10;
   nr=nr/10;
 }
 return max;
}
void main()
{ int a,b,k=0;
  cout<<"Dati a: "; cin>>a;
  cout<<"Dati b: "; cin>>b;
  for (int i=a;i<b;i++)
   if (sumcif(i)==maxcif(i)) k++;
  cout<<k<<endl; k=0;
  for (i=a;i<b;i++)
   for (int j=i+1;j<=b;j++)
    if (sumcif(i)==sumcif(j)) k++;
  cout<<k<<endl;
}