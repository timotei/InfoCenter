#include<fstream.h>
#include<string.h>
char c[40][200]={'0'};
int n,m,x[100];
void afis()
{
 for (int i=1;i<=m;i++)
  cout<<c[x[i]]<<" ";
 cout<<endl;
}
int verif(int i)
{
 for(int j=2;j<i;j++)
	if (x[i]==x[j]) return 0;

 if (j>1 && strcmp(c[x[i]],c[x[i-1]]) ==0) return 0;
 return 1;
}
void gen(int i)
{
  for(int j=1;j<=n;j++)
  {
	x[i]=j;

	if (verif(i))
	  if (i==m) afis();
	  else gen(i+1);
  }
}
void main()
{
 cout<<endl;
 ifstream fin("date.in");
 fin>>n>>m;
 for (int i=1;i<=n;i++)
  fin>>c[i];
 fin.close();
 gen(1);

}