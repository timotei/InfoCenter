#include <iostream.h>

long x[100],s=0;
//int k;

long nr(int k)
{long nr=0;
 for(int j=1;j<=k;j++)
  nr=nr*10+x[j];
 return nr;
}
int verif(int i)
{
 for(int j=1;j<i;j++)
  if(x[j]==x[i]) return 0;
 return 1;
}
void gen(int i,int k)
{

 for(int j=1;j<=9;j+=2)
 { x[i]=j;

   if(verif(i))
     if(i==k) s=s+nr(k);
     else gen(i+1,k);
 }
}

void main()
{
 for(int k=1;k<=5;k++)
  gen(1,k);
 cout<<"suma este: "<<s;
 cout<<endl;
}