#include<iostream.h>
int x[100],sir[100],n,sol=0;
void afis()
{
 for (int i=1;i<=n;i++)
  cout<<sir[x[i]]<<" ";
 cout<<endl;
 sol++;
}
void gen(int i)
{
 for (int j=1;j<=n;j++)
  {
   x[i]=j;
   if (i==n) afis();
   else gen(i+1);
  }
}
void main()
{
 cout<<"Dati n: "; cin>>n;
 cout<<"Dati elem: ";
 for (int i=1;i<=n;i++)
  cin>>sir[i];
 gen(1);
 cout<<"Total solutii: "<<sol<<endl;
}