#include<fstream.h>
int x[15000],n;
void quick(int st, int dr)
{
 int i=st,j=dr,ii=0,jj=-1,aux;
 if (st<dr)
 {
  while(i<j)
  {
   if (x[i]>x[j])
   {
    aux=x[i]; x[i]=x[j];
    x[j]=aux; aux=ii;
    ii=-jj; jj=-aux;
   }
   i=i+ii;j=j+jj;
  }
  quick(st,i-1);
  quick(i+1,dr);
 }
}
void main()
{
 cout<<endl;
 int i=1;
 ifstream fin("quick.in");
 while(fin>>x[i]) i++;
 n=i-1;
// for (i=1;i<=n;i++)
//  cout<<x[i]<<" ";
// cout<<endl;
 quick(1,n);
  for (i=1;i<=n;i++)
  cout<<x[i]<<" ";
 cout<<endl;
 fin.close();
}