#include<fstream.h>
int x[100],n;
// CMMDC dintre doua nr
int cmdc(int k1, int k2)
{
 while (k1!=k2)
  {
   if (k1<k2) k2-=k1;
   else k1-=k2;
  }
 return k1;
}
// CMMDC ale tuturor numerelor
int cmmdc(int st, int dr)
{
 if (st==dr) return x[st];
 else
 {
  int m=(st+dr)/2;
  int k1=cmmdc(st,m);
  int k2=cmmdc(m+1,dr);
  return cmdc(k1,k2);
 }
}
int cmmc(int st, int dr)
{
 if (st==dr) return x[st];
 else
 {
  int m=(st+dr)/2;
  double p1=cmmc(st,m);
  double p2=cmmc(m+1,dr);
  return p1*p2/cmdc(p1,p2);

 }
}
void main()
{
 cout<<endl;
 ifstream fin("date.in");
 fin>>n;
 for (int i=1;i<=n;i++)
  fin>>x[i];
 fin.close();
 cout<<"CMMDC: "<<cmmdc(1,n)<<endl;
 cout<<"CMMMC: "<<cmmc(1,n)<<endl;
}