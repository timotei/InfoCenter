#include<fstream.h>
ofstream f("timo.out");
void genSir(long tmp[50], int &k, int n)
{
 int x=0,i=1,j=1;
 do
 {
  i=j; j=x;
  x=i+j;
  if(x<=n) {tmp[k]=x; k++;}
   else break;
  }
 while(x<=n);
}
void inverSir(long x[50],int i)
{
 if (i>0) { f<<x[i]<<" "; inverSir(x,i-1); }
}
void main()
{
int n;
cout<<"Dati n: "; cin>>n;
int k=1;
long tmp[50]={0};
genSir(tmp,k,n);
inverSir(tmp,k-1);
f.close();
}