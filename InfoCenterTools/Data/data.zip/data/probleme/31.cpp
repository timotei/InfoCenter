#include<fstream.h>
struct nod
{
int nr;
nod *urm;
};
void add(nod *&v, int nr)
{
nod *p=new nod;
p->nr=nr;
p->urm=v;
v=p;
}
int isPrim(int nr)
{
for (int i=2;i<=nr/2;i++)
 if (nr%i==0) return 0;
return 1;
}
void crrNeprime(nod *v, nod *&v2)
{
 while (v)
 {
  if (!isPrim(v->nr)) add(v2,v->nr);
  v=v->urm;
 }
}
int nCifre(int nr)
{
 if (nr) return 1+nCifre(nr/10);
 return 0;
}
void afis(nod *v)
{while (v) {cout<<v->nr<<"-"<<nCifre(v->nr)<<" "; v=v->urm;}
cout<<endl;
}
void main()
{
 nod *v=NULL,*v2=NULL;
 int nr;
 ifstream fin("prim.in");
 while (fin>>nr)
  add(v,nr);
 fin.close();
 crrNeprime(v,v2);
 cout<<"Nr neprime: "; afis(v2);
}