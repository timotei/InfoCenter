#include<fstream.h>
int x[200]={0},n,k;
char sir[100][20];

void afis()
{
 for (int i=1;i<=k;i++)
  cout<<sir[x[i]]<<" ";
 cout<<endl;
}
void gen(int i)
{
  for (int j=x[i-1]+1;j<=n;j++)
  {
   x[i]=j;
   if (i==k) afis();
   else gen(i+1);
  }
}
void main()
{
 ifstream fin("nr.in");
 fin>>n>>k;
 for (int i=1;i<=n;i++)
  fin>>sir[i];
 gen(1);
 fin.close();
}