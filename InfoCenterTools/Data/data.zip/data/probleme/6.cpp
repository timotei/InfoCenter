#include<iostream.h>
#include<conio.h>
#include<math.h>
int functie(float a, float b)
{
int a1,b1;
int nr;
a1=a;
b1=b;
if (int(a)==a )nr=1;
else nr=0;
nr=nr+b1-a1;
return nr;
}
void main ()
{
clrscr();
float a,k;
cout<<"Dati a: "; cin>>a;
cout<<"Dati k: "; cin>>k;
cout<<"Nr: "<<functie(pow(19,k-1)/a,pow(10,k+1)-1/a)<<endl;
}