#include<fstream.h>
#include<math.h>
 
int sumaDiv(int nr, int i)
{
 if (i<=nr/2)
 {
  if (nr%i==0)
     return i+sumaDiv(nr,i+1);
  return sumaDiv(nr,i+1);
 }
 else return 0;
}
int perf(int nr)
{
if (nr == sumaDiv(nr,1))
 return 1;
else return 0;
}
 
void main()
{
 int n,i=1,j=0;
 float nr, x[50];
 ifstream fin("timo.in");
 fin>>n;
 while (fin>>nr)
 { x[i]=nr; i++;}
 fin.close();
 ofstream fout("timo.out");
 for (i=1;i<=n;i++,)
  if (perf((int)x[i])==1) {fout<<x[i]<<" "; j++;}
       if (j==0) fout<<”Nu Exista”<<endl;
 fout.close();
}