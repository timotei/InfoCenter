#include<fstream.h>
int n,x[10][10];
ofstream fout("date.out");
void afis()
{
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   fout<<x[i][j]<<" ";
  fout<<endl;
 }
 fout<<endl;
}
int verif()
{
 int z,ln,a;
 for(z=1;z<=n;z++)
 {
  ln=0;
  for(a=1;a<=n;a++)
   if (x[z][a]==0) ln++;
  if (ln>1|| ln==0) return 0;
 }
 for(z=1;z<=n;z++)
 {
  ln=0;
  for(a=1;a<=n;a++)
   if (x[a][z]==0) ln++;
  if (ln!=1)  return 0;
 }
 return 1;
}
void gen(int i,int k)
{
 for (int j=0;j<=1;j++)
 {
  x[i][k]=j;
   if (i==n)
    if (k==n)
    {
     if (verif()) afis();
    }
    else gen(1,k+1);
   else gen(i+1,k);
 }
}
void main()
{
 cout<<"Dati n: "; cin>>n;
 gen(1,1);
 fout.close();
}