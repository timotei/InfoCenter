#include<fstream.h>
#include<iomanip.h>
int x[100];
int minim(int st, int dr)
{
 if (st==dr)
 {  if (x[st]>=10 && x[st]<=99) return x[st];
	else return 30000;
 }
 else
 {
  int m=(st+dr)/2;
  int m1=minim(st,m);
  int m2=minim(m+1,dr);
  if (m1<m2) return m1;
  else return m2;
 }
}
void main()
{
 int n;
 cout<<endl<<endl;
 ifstream fin("date.in");
 fin>>n;
 for (int i=1;i<=n;i++)
  fin>>x[i];

 cout<<"min: "<<minim(1,n)<<endl;
 fin.close();
}