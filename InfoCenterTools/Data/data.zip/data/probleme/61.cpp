#include <iostream.h>
void hanoi(int n, char ta,char tb, char tc)
{
 if (n==1) cout<<ta<<"-"<<tb<<" ";
 else{
  hanoi(n-1,ta,tc,tb);
  cout<<ta<<"-"<<tb<<" ";
  hanoi(n-1,tc,tb,tc);
 }
}
void main()
{
 cout<<endl<<endl;
  int n;
  char ta='A',tb='B',tc='C';
  cout<<"Dati n: "; cin>>n;
  hanoi(n,ta,tb,tc);
}