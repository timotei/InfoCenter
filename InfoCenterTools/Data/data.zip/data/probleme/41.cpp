#include<fstream.h>
#include<conio.h>
#include<values.h>
struct nod{
 int nr;
 nod *urm;
};
void add(nod *&v, int nr)
{
 nod *p=new nod;
 p->nr=nr;
 p->urm=v;
 v=p;
}
void creare(nod *&v)
{
 int nr;
 ifstream fin("dt.in");
 while (fin>>nr)
  add(v,nr);
 fin.close();
}
void afis(nod *v)
{
 while (v)
 { cout<<v->nr<<" "; v=v->urm; }
 cout<<endl;
}
void stergeElem(nod *v, int nr)
{
 nod *p=v;
 while (p->urm->nr!=nr) p=p->urm;

 nod *q=p->urm;
 p->urm=p->urm->urm;
 delete q;
}
void afisMin(nod *&v)
{
 int m1=MAXINT,
     m2=MAXINT,
     m3=MAXINT;
 nod *p=v;
 while (p)
 {
  if (p->nr<m1) {m3=m2;m2=m1;m1=p->nr;}
  else if(p->nr<m2) {m3=m2; m2=p->nr;}
  else if (p->nr<m3) m3=p->nr;
  p=p->urm;
 }
 cout<<"Minimurile "<<m1<<" "<<m2<<" "<<m3<<endl;
 stergeElem(v,m1);
 stergeElem(v,m2);
 stergeElem(v,m3);
}
void main()
{
 cout<<endl<<endl;
 nod *v=NULL;
 creare(v);
 cout<<"S: ";afis(v);
 afisMin(v);
 cout<<"S: "; afis(v);
}