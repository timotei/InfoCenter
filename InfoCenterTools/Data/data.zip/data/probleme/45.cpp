// !!! NU ORDONEAZA SI DUPA NUME!!!
#include<fstream.h>
#include<string.h>
#include<iomanip.h>
#include<conio.h>
struct nod{
 char num[100];
 char cls[100];
 float med;
 nod *urm;
};
void add(nod *v, char num[], char cls[], float m)
{
 nod *p=v;
 while (strcmp(p->cls,cls)<0)
   p=p->urm;
 //TODO: ordonare dupa nume
 nod *q=new nod;
 strcpy(q->num,num);
 strcpy(q->cls,cls);
 q->med=m;
 q->urm=p->urm;
 p->urm=q;
}
void afisDupaClasa(nod *v)
{
 nod *p=v->urm;
 char cls[100]="";
 while (p!=NULL)
 {
  if (strcmp(p->cls,cls)==0)
  {
    cout<<"    "<<setw(9)<<p->num<<"|"<<setw(5)<<p->med<<"|"<<endl;
    p=p->urm;
  }
  else
  {
   strcpy(cls,p->cls);
   cout<<setw(8)<<"Clasa: "<<cls<<setw(9)<<"|Media|"<<endl;
  }
 }
}
void creare(nod *&v)
{
 ifstream fin("dt.in");
 char num[100], cls[100]; float med;
 v=new nod;
 nod *p=v;
 v->urm=NULL;
 p->urm=NULL;
 strcpy(p->cls,"zzzzzzzzzz");
 while (fin>>num)
 {
  fin>>cls; fin>>med;
  add(v,num,cls,med);
 }
 fin.close();
}
void afis(nod *v)
{
 cout<<"Elev     |Clasa|Media|"<<endl;
 for(nod *p=v->urm;p;p=p->urm)
 {
  cout<<setw(9)<<p->num<<"|"<<setw(5)<<p->cls<<"|"<<setw(5)<<p->med<<"|"<<endl;
 }
 cout<<endl;
}
void main()
{
 clrscr();
 cout<<endl<<endl;
 nod *v;
 creare(v);
 afis(v);
 cout<<"Afis dupa clasa:"<<endl;
 cout<<"================"<<endl;
 afisDupaClasa(v);
}