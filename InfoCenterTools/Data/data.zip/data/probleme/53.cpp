#include<fstream.h>
#include<conio.h>
struct nod{
 int nr;
 nod *urm;
};
void add(nod *v, int nr)
{
 nod *p=v;
 while (p->urm->nr<nr) p=p->urm;

 nod *q=new nod;
 q->nr=nr;
 q->urm=p->urm;
 p->urm=q;
}
void creare(nod *&v)
{
 v=new nod;
 nod *p=new nod;
 v->urm=p;
 p->urm=NULL;
 p->nr=9999;
 int nr;
 ifstream fin("info.in");
 while(fin>>nr) add(v,nr);
 fin.close();
}
void crearePare(nod *v, nod *&v2)
{
 v2=new nod;
 nod *p=new nod;
 v2->urm=p;
 p->urm=NULL;
 p->nr=9999;

 for(nod *q=v->urm;q->urm;q=q->urm)
  if(q->nr%2==0) add(v2,q->nr);
}
void stergeNr(nod *v)
{
 for (nod *p=v;p->urm;p=p->urm)
  if(p->urm->nr>99 && p->urm->nr<1000)
  {
   nod *q=p->urm;
   p->urm=q->urm;
   delete q;
   return;
  }
}
void afisMax(nod *v, nod *v2)
{
 int i=0;
 for (nod *p=v->urm;p->urm;p=p->urm)
 {
  int ok=1;
  for (nod *q=v2->urm;q->urm;q=q->urm)
   if(p->nr<=q->nr) { ok=0; break; }
  if(ok==1) i++;
 }
 cout<<i<<" elemente mai mari ca toate din lista 2."<<endl;
}
void add(nod *&v, nod *&u, int nr)
{
 nod *q=new nod;
  q->nr=nr;
  q->urm=NULL;
  if (v==NULL) v=q;
   else u->urm=q;
  u=q;
		  }
void concat(nod *v,nod *v2)
{
 nod *u=NULL; nod *v3=NULL;
 for(nod *p=v->urm;p->urm;p=p->urm)
   add(v3,u,p->nr);
 for(p=v2->urm;p->urm;p=p->urm)
   add(v3,u,p->nr);
 cout<<"Lista concat: ";
 for(nod *r=v3;r!=NULL;r=r->urm)
  cout<<r->nr<<" ";
 cout<<endl;
}
void afis(nod *v)
{
 for(nod *p=v->urm;p->urm;p=p->urm)
  cout<<p->nr<<" ";
 cout<<endl;
}
void main()
{
 clrscr();
 nod *v,*v2;
 creare(v);
 cout<<"Lista: "; afis(v);
 crearePare(v,v2);
 cout<<"Lista cu nr pare: "; afis(v2);
 stergeNr(v);
 cout<<"Lista: "; afis(v);
 afisMax(v,v2);
 concat(v,v2);
}