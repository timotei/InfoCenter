#include<fstream.h>
int a[100][100],n,m;
void citire()
{
 int x,y,i;
 ifstream fin("graf.in");
 fin>>n>>m;
 for (i=1;i<=m;i++)
 {
  fin>>x>>y;
  a[x][y]=1;
 }
 fin.close();
}
void transforma()
{
 for (int k=1;k<=n;k++)
  for (int i=1;i<=n;i++)
   if (i!=k)
    for (int j=1;j<=n;j++)
     if (j!=k)
      if (a[i][j]==0) a[i][j]=(a[i][k]<a[k][j]?a[i][k]:a[k][j]);

}
void afisMat()
{
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void main()
{
 citire();
 afisMat();
 transforma();
 afisMat();
}