#include<fstream.h>
int n,m,a[20][20];
void cit(char path[])
{
 ifstream fin(path);
 fin>>n>>m;
 for (int i=1;i<=m;i++)
 {
  int x,y;
  fin>>x>>y;
  a[x][y]=a[y][x]=1;
 }
}
void afisMat()
{
 for(int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void main()
{
 int nod,i,j,vec[20]={0},nrvec=0;
 int gr=0,max=0;

 cit("graf.in");
 cout<<"a)"<<endl;
 afisMat();

 cout<<"b) Dati nod: "; cin>>nod;
 for (i=1;i<=n;i++)
  if (a[nod][i]) gr+=1;
 cout<<"Grad: "<<gr<<endl;

 cout<<"c) Nodurile adiacente: ";
 for (i=1;i<=n;i++)
  if (a[nod][i]) cout<<i<<" ";
 cout<<endl;

 cout<<"d) Gradele nodurilor: "<<endl;
 for (i=1;i<=n;i++)
 {
  gr=0;
  cout<<i<<": ";
  for (j=1;j<=n;j++)
   if (a[i][j]) gr+=1;
  cout<<gr<<endl;
  if (gr>max) max=gr;
 }

 cout<<"e) Nodurile izolate: ";
 for (i=1;i<=n;i++)
 {
   gr=0;
   for (j=1;j<=n;j++)
    if (a[i][j]) gr+=1;
   if (gr==0) cout<<i<<" ";
   else if (gr==max) vec[++nrvec]=i;
 }
 cout<<endl;

 cout<<"f) Nodurile cu cei mai multi vecini: ";
 for (i=1;i<=nrvec;i++)
  cout<<vec[i]<<" ";
 cout<<endl;

 cout<<"g) Lista de adiacenta: ";
 for (i=1;i<=n;i++)
 {
  cout<<i<<": ";
  for (j=1;j<=n;j++)
   if (a[i][j]) cout<<j<<" ";
  cout<<endl;
 }
 cout<<endl;
}