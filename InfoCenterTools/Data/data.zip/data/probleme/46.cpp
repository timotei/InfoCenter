#include<fstream.h>
#include<conio.h>
struct nod {
 int nr;
 nod *urm;
};
int n;
void add(nod *&v, nod *&u, int nr)
{
 nod *p=new nod;
 p->nr=nr;
// p->urm=NULL;
 if (v==NULL) v=p;
  else u->urm=p;
 u=p;
 u->urm=v;
}
void creare(nod *&v, nod *&u, int n)
{
 u=NULL;
 for (int i=1;i<=n;i++)
  {
   add(v,u,i);
   u->urm=v;
  }
}
void joaca(nod *&v, nod *&u, int k, int n)
{
 nod *p=v;int i,j;
 cout<<"Copii scosi: ";
 while (v->urm!=u && n>1)
  for (j=1;j<n;j++)
   {
    for (i=1;i<k;i++) v=v->urm;
    nod *q=v->urm;
    v->urm=q->urm;
    cout<<q->nr<<" ";
    delete q;
    n--;
   }
 cout<<"Castiga: "<<v->nr<<endl;

}
void afis(nod *v)
{
 nod *p=v;
 do
 {
  cout<<p->nr<<" ";
  p=p->urm;
 }
 while (p!=v);
 cout<<endl;
}
void main()
{
 clrscr();
 nod *v=NULL,*u; int k;
 cout<<"Dati n: "; cin>>n;
 cout<<"Dati k: "; cin>>k;
 creare(v,u,n);
 cout<<"Copii: ";afis(v);
 joaca(v,u,k,n);
 cout<<"Copii: "; afis(v);
}