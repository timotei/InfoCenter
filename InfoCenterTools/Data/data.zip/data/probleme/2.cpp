#include<iostream.h>
#include<math.h>

void main()
{
 int n=0;
 cout<<"Dati n(impar): "; cin>>n;
 while (n%2!=1)
 {
  cout<<"Trebuie un numar impar: "; cin>>n;
 }
 float calc=0;
 for (int i=1;i<=n;i++)
 {
  if (i%2==1) calc=calc+sqrt(i);
  else calc=calc-sqrt(i);
 }
 cout<<"Calculul: "<<calc<<endl;
}