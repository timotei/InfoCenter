#include <fstream.h>
#include <conio.h>
void main()
{
clrscr();
ifstream fin("cifre.in");
int a[10]={0};
char c;
int i=1,n;
while (fin>>c)
 { n=c-'0'; a[n]++;}
for (i=9;i>=0;i--)
 while (a[i])
  {
   cout<<i;
   a[i]--;
  }
fin.close();
}