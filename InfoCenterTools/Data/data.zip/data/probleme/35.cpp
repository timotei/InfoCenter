#include<fstream.h>
#include<conio.h>
#include<values.h>
struct nod{
 int nr;
 nod *urm;
};
void add(nod *&v, int nr)
{
 nod *p=new nod;
 p->nr=nr;
 p->urm=v;
 v=p;
}
void creare(nod *&v)
{
 int nr;
 ifstream fin("dte.in");
 while (fin>>nr)
  add(v,nr);
 fin.close();
}
void afis(nod *v)
{
 while (v)
 { cout<<v->nr<<" "; v=v->urm; }
}
void afisMin(nod *v)
{
 int m1=MAXINT,
     m2=MAXINT,
     m3=MAXINT;
 nod *p=v;
 cout<<endl;
 while (p)
 {
  cout<<p->nr<<" ";
  if (p->nr<m1) {m3=m2;m2=m1;m1=p->nr;}
  else if(p->nr<m2) {m3=m2; m2=p->nr;}
  else if (p->nr<m3) m3=p->nr;
  p=p->urm;
 }
 cout<<"\nMinimurile "<<m1<<" "<<m2<<" "<<m3<<endl;
}
void main()
{
 cout<<endl<<endl;
 nod *v=NULL;
 creare(v);
 cout<<"Stiva: ";afis(v);
 afisMin(v);
}