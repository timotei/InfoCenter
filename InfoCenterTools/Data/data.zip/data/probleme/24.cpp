#include <iostream.h>
int cmmdc(int n, int k)
{
 int r;
 do{
  r=n%k;
  n=k;
  k=r;
 }while(r);
 return r;
}
void main()
{
 int a[50],n,cmd,cm;
 cout<<"Dati n: "; cin>>n;
 cout<<"Dati elem: ";
 for (int i=1;i<=n;i++)
  cin>>a[i];
 cmd=a[1];
 for (i=2;i<=n;i++)
  cmd=cmmdc(cmd,a[i]);
 cout<<"CMMDC: "<<cmd<<endl;
 cm=a[1];
 for (i=2;i<=n;i++)
  cm=(cm*a[i]) /cmmdc(cm,a[i]);
 cout<<"CMMC: "<<cm<<endl;
 cmd=0;
 for (i=1;i<n;i++)
  for (int j=i+2;j<=n;j++)
   if (cmmdc(a[i],a[j])>cmd) cmd=cmmdc(a[i],a[j]);
 cout<<"CMMDC perechi: "<<cmd<<endl;
}