#include<fstream.h>
struct nod{
int nr;
nod *urm;
};
void add(nod *&v, int nr)
{
nod *p=new nod;
p->nr=nr;
p->urm=v;
v=p;
}
int identice(nod *v, nod *v2)
{
 while (v)
 { if(v->nr!=v2->nr) return 0;
  v=v->urm;
  v2=v2->urm;
 }
 return 1;
}
void main()
{
nod *v=NULL,*v2=NULL;
ifstream f("f.txt");
ifstream f2("f2.txt");
int nr,i1=0,i2=0;
while (f>>nr)
 {add(v,nr); i1++;}
while (f2>>nr)
 {add(v2,nr); i2++;}
if (i1==i2)
 {
  if (identice(v,v2)) cout<<"Sunt Identice"<<endl;
  else cout<<"Sunt Identice"<<endl;
 }
else cout<<"Nu sunt identice"<<endl;
f.close();
f2.close();
}