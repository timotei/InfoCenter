#include<fstream.h>
#include<conio.h>
struct nod{
 int nr;
 nod *ant;
 nod *urm;
};
nod *u=NULL;
void add(nod *&v, int nr)
{
 nod *q=new nod;
 q->nr=nr;
 q->urm=NULL;
 q->ant=u;
 if(v==NULL) v=q;
 else u->urm=q;
 u=q;
}
void creare(nod *&v)
{
 int nr;
 ifstream fin("info.in");
 while(fin>>nr) add(v,nr);
 fin.close();
}
void afis(nod *v)
{
 while(v){ cout<<v->nr<<" "; v=v->urm; }
 cout<<endl;
}
void afisCoada()
{
 nod *p=u;
 while(p){ cout<<p->nr<<" "; p=p->ant; }
 cout<<endl;
}
int getMaxNr(nod *v)
{
 int max=0;
 while(v) { if (v->nr>max) max=v->nr; v=v->urm; }
 return max;
}
nod* DetermAparMax(nod *v)
{
 int max=getMaxNr(v);
 nod *p=v;
 while(p->nr!=max) p=p->urm;
 return p;
}
void afisSume(nod *v, nod *max)
{
 cout<<"Max: "<<max->nr<<endl;
 int s1=0,s2=0;
 for(nod *p=v;p!=max;p=p->urm)
  s1+=p->nr;
 for(p=p->urm;p;p=p->urm)
  s2+=p->nr;
 cout<<"Suma1: "<<s1<<endl;
 cout<<"Suma2: "<<s2<<endl;
}
void cautaMaxElemente(nod *v, nod *max)
{
 int i1=0,i2=0;
 for(nod *p=v;p!=max;p=p->urm)
  i1++;
 for(p=p->urm;p;p=p->urm)
  i2++;
 if(i1==i2) cout<<"Amble parti au acelasi nr de elemente."<<endl;
 else
 {
  if(i1>i2) cout<<"Prima parte";
   else cout<<"A doua parte";
  cout<<" contine mai multe elemente."<<endl;
 }
}
void main()
{
 clrscr();
 nod *v=NULL,*max;
 creare(v);
 cout<<"Lista : "; afis(v);
 cout<<"Lista2: "; afisCoada();
 max=DetermAparMax(v);
 afisSume(v,max);
 cautaMaxElemente(v,max);
}