#include<iostream.h>
#include<string.h>
#include<conio.h>
void main()
{
 clrscr();
 char x[500]={0},ch=' ';
 cout<<"Dati sir: "; cin>>x;
 cout<<"Dati ch: "; cin>>ch;
 char *p=strchr(x,ch);
 char *q=strchr(p+1,ch);
 cout<<"sunt x elemente: "<<q-p-1;
}