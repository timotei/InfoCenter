#include<fstream.h>
struct el { int x; int y; int cost; int vf; };
el a[100];
int b[100],n,m;

void citire()
{
 ifstream fin("graf.in");
 int i;
 fin>>n>>m;
 for(i=1;i<=m;i++)
 {
  fin>>a[i].x>>a[i].y>>a[i].cost;
  a[i].vf=0;
 }
 fin.close();
}
void ord()
{
 for (int i=1;i<m;i++)
  for (int j=i+1;j<=m;j++)
   if (a[i].cost>a[j].cost)
   {
    el aux=a[i];
    a[i]=a[j];
    a[j]=aux;
   }
}
void afis()
{
 cout<<"Muchiile arborelui: ";
 for (int i=1;i<=m;i++)
  if (a[i].vf==1)
   cout<<a[i].x<<"-"<<a[i].y<<" ";
 cout<<endl;
}
void main()
{
 citire();
 ord();
 int i=1,k=0,q,d,f;
 for(i=1;i<=n;i++) b[i]=i
 while(k<(n-1))
 {
  d=a[i].x; f=a[i].y;
  if (b[d]!=b[f])
  {
   for (q=1;q<=n;q++)
    if(b[d]==b[q])
     b[q]=b[f];
   a[i].vf=1;
   k++;
  }
  i++;
 }
 afis();
}