#include<fstream.h>

void main(){
  long x[50],y[50] ;
  int n1,n2;
  ifstream fin("f1.txt");
  ifstream fin2("f2.txt");
  ofstream fout("f3.txt");
  fin>>n1; fin2>>n2;
  while (!fin.eof() && !fin2.eof())
   if(n1>n2) { fout<<n1<<" "; fin>>n1;}
   else {fout<<n2<<" ";  fin2>>n2;}
  if(!fin.eof()) fout<<n1<<" ";
  if(!fin2.eof()) fout<<n2<<" ";
  while (fin>>n1)
   fout<<n1<<" ";
  while (fin2>>n1)
   fout<<n2<<" ";
  fin.close();
  fin2.close();
  fout.close();

}