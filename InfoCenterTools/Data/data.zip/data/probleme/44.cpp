#include<fstream.h>
#include<string.h>
struct nod{
 char c[20];
 int fr;
 nod *urm;
};
void add(nod *v, char c[])
{
 nod *p=v;
 while(strcmp(p->urm->c,c) < 0) p=p->urm;
 if (strcmp(p->urm->c,c)==0)	p->urm->fr++;
  else
  {
	nod *q=new nod;
	q->fr=1;
	strcpy(q->c,c);
	q->urm=p->urm;
	p->urm=q;
  }
}
void afis(nod *v)
{

 for(nod *p=v->urm;p->urm!=NULL;p=p->urm)
  cout<<p->c<<"-"<<p->fr<<endl;
 cout<<endl;
}
void creare(nod *&v)
{
 char c[100];
 ifstream fin("dt.in");
 v=new nod;
 nod *p=new nod;
 v->urm=p;
 p->urm=NULL;
 strcpy(p->c,"zzzzzzzzzz");
 while (fin>>c)
	add(v,c);
 fin.close();
}
void main()
{
 cout<<endl<<endl;
 nod *v;
 creare(v);
 cout<<"Lista: "; afis(v);

}