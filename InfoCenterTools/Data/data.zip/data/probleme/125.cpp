#include<fstream.h>
int a[100][100],n,m;
void citire()
{
 ifstream fin("graf.in");
 fin>>n>>m;
 int x,y;
 for (int i=1;i<=m;i++)
 {
  fin>>x>>y;
  a[x][y]=1;
 }
 fin.close();
}
void afisMat()
{
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void main()
{
 citire();
 afisMat();

 int celeb=0,i,j,c1,c2;
 for(i=1;i<=n;i++)
 {
  c1=c2=0;
  for (j=1;j<=n;j++)
  {
   if (a[i][j]) c1++;
   if (a[j][i]) c2++;
  }
  if (c2==(n-1) && c1==0){ cout<<i<<" este o celebritate."<<endl; celeb=1; }
 }
 if (!celeb) cout<<"ne pare rau dar nu avem celebritati."<<endl;
}