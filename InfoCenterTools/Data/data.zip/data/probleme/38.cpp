#include<fstream.h>
struct nod {
  int nr;
  nod *urm;
};
void add(nod *&v, int n)
{
 nod *p=new nod;
 p->nr=n;
 p->urm=v;
 v=p;
}
void creare(nod *&v)
{
 int nr;
 ifstream fin("timo.in");
 while (fin>>nr)
  add(v,nr);
 fin.close();
}
void afis(nod *v)
{
 while(v)
 { cout<<v->nr<<" "; v=v->urm; }
 cout<<endl;
}
void sterge(nod *&v)
{
 nod *p=v;
 v=v->urm->urm;
 delete p;
}
void stergeNrPare(nod *&v)
{
 nod *p,*q;
 while (v->nr%2==0 && v!=NULL)
 {
  p=v;
  v=v->urm;
  delete p;
 }
 p=v;
 while (p->urm)
  if (p->urm->nr%2==0)
  {
   q=p->urm;
   p->urm=q->urm;
   delete q;
  }
  else p=p->urm;

}
void main()
{
 cout<<endl<<endl;
 nod *v=NULL;
 creare(v);
 cout<<"Lista: ";afis(v);
 stergeNrPare(v);
 cout<<"Lista: "; afis(v);
}