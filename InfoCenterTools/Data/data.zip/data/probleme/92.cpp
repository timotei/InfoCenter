#include<iostream.h>
#include<conio.h>
long n, k,cif=1,x[100],nr[100],max=0;
long getNr()
{
 long nou=0;
 for (int i=1;i<=cif-k;i++)
  nou=nou*10+nr[x[i]];
 return nou;
}
int verif(int i)
{
 for (int j=1;j<i;j++)
  if (x[i]==x[j]) return 0;
 return 1;
}
void gen(int i)
{
 for (int j=1;j<=cif;j++)
 {
  x[i]=j;
  if (verif(i))
   if (i==cif-k)
   {
    if (getNr()>max) max=getNr();
   }
   else gen(i+1);
 }
}
void main()
{
 clrscr();
 cout<<"Dati nr: "; cin>>n;
 cout<<"Dati k: "; cin>>k;

 int aux=n;
 while(aux)
 {nr[cif]=aux%10; aux=aux/10; cif++;}
 cif--;

 gen(1);
 cout<<"Nr max: "<<max;
}