#include<fstream.h>
#include<string.h>
#include<conio.h>
struct prog{ char nume[100]; int min; prog *urm;};

void add(prog *&v, char c[100], int nr)
{
prog *p=new prog;
strcpy(p->nume,c);
p->min=nr; p->urm=v; v=p;
}

void afis(prog *v)
{
 cout<<"Programari: "<<endl<<"====================="<<endl;
 while (v)
  {  cout<<v->nume<<" - "<<v->min<<endl; v=v->urm; }
cout<<endl;
}

void trateazaPacienti(prog *v, int x, int y)
{
 int hr=x*100; y=y*100;
 cout<<"Se trateza...(Orar: "<<hr<<"-"<<y<<")"<<endl;
 while (hr<=y && v)
 {
  cout<<"Ora: "<<hr<<"|"<<v->nume<<" sta "<<v->min<<endl;
  hr=hr+v->min;
  // Se trece peste 60 de minute. Se adauga o ora :P
  if (hr%100>60) {hr=(hr/100+1)*100+(hr%100-60);}
  v=v->urm;
 }
 if(v==NULL) cout<<"Nu mai sunt programari. Se merge acasa...";
 else
 {
  if (hr>y) cout<<v->nume<<" a fost tratat partial"<<endl;
  cout<<"Mai exista programari... Se reprogrameaza:"<<endl;
  while(v) {cout<<v->nume<<endl; v=v->urm; }
 }
}
void main()
{
 clrscr(); prog *v=NULL; int x=0,y=0; char nm[100]; int min;
 ifstream fin("prog.in"); fin>>x; fin>>y;
 while (fin>>nm){fin>>min; add(v,nm,min); }
 afis(v);
 trateazaPacienti(v,x,y);
}