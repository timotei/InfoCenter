#include<fstream.h>
#include<string.h>
struct nod
{
 char x;
 nod *urm;
};
void add(nod *&v,nod *&u,char x)
{
 nod *p=new nod;
 p->x=x;
 p->urm=NULL;
 if(v==NULL) v=p;
 else u->urm=p;
 u=p;
}
void creare(nod *&v)
{
 char x;
 v=NULL;
 nod *u=NULL;
 ifstream f("info.in");
 while (f>>x) add(v,u,x);
 u->urm=v;
}
void afis(nod *v)
{
 nod *p=v;
 do{ cout<<p->x<<"  "; p=p->urm; }while(p!=v);
 cout<<endl;
}
void main()
{
 nod *v;
 creare(v);
 afis(v);
 int n,j=0; char out[40];
 nod *p=v;
 ifstream fin("cifru.in");
 while(fin>>n)
 {
  for(int i=1;i<=n;i++) p=p->urm;
  out[j]=p->x; j++;
  n=n/10;
 }
 out[j]='\0';
 cout<<"Cuvantul: "<<out<<endl;
 fin.close();
}