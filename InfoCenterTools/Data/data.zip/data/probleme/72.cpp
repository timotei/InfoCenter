#include<iostream.h>
#include<string.h>
int l,x[100],k; char c[200];
int verif(int i)
{
 for (int j=0;j<i;j++)
  if (x[j]==x[i]) return 0;
 return 1;
}
void afis()
{
  for (int i=0;i<k;i++)
   cout<<c[x[i]];
  cout<<endl;
}
void lit(int i)
{
 for (int j=0;j<l;j++)
 {
  x[i]=j;
  if(verif(i))
   if (i==k-1)
    afis();
   else lit(i+1);
 }
}
void main()
{
 cout<<"Dati cuvant:"; cin>>c;
 cout<<"Dati k: "; cin>>k;
 l=strlen(c);
 lit(0);
}