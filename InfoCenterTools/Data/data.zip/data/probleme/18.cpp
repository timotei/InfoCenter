#include<iostream.h>
#include<conio.h>
struct nod{ int nr; nod *urm; };
void add(nod *&v, int nr)
{
 nod *p=new nod;
 p->nr=nr;
 p->urm=v;
 v=p;
}
void creare(nod *&v)
{
 cout<<"Dati elemente: ";
 int nr;
 do
 {
  cin>>nr; if (nr!=0) add(v,nr);
 }
 while(nr!=0);
 cout<<endl;
}
void afis(nod *v)
{
 while (v)
 { cout<<v->nr<<" "; v=v->urm; }
}
void afisPare(nod *v)
{
 cout<<"Numerele pare: ";
 while (v)
 { if (v->nr%2==0) cout<<v->nr<<" "; v=v->urm; }
 cout<<endl;
}
void nrPozPare(nod *v)
{
 cout<<"Numerele de pe poz Pare: ";
 int poz=1;
 while(v)
 {
  if (poz%2==0) cout<<v->nr<<" ";
  poz++;  v=v->urm;
 }
 cout<<endl;
}

int isNrPrim(int nr)
{
 if (nr==2) return 1;
 for (int i=2;i<=nr/2;i++)
  if (nr%i==0) return 0;
 return 1;
}
void str(nod *&v)
{
 if (v) {
  nod *p=v; v=v->urm; delete p; }
}
void sterge(nod *v)
{
 nod *k=new nod;  k=v;
 while (k)
 {
  if(isNrPrim(k->nr)==0) {
  str(k);   k=k->urm;}
  else break;
 }
 cout<<"Stiva pana la nr prim: ";
 afis(k);
}
void nrDeLaBaza(nod *v)
{
 while (v->urm) v=v->urm;
 cout<<"Nr de la baza: "<<v->nr<<endl;
}
int nrElemStiva(nod *v)
{
 int i=0;
 while (v) { i++; v=v->urm; }
 return i;
}
void main()
{
 clrscr();
 nod *v=NULL; creare(v);
 cout<<"Elementele sunt: ";
 afis(v); afisPare(v);
 nrPozPare(v); sterge(v);
 nrDeLaBaza(v);
 cout<<"Sunt "<<nrElemStiva(v)<<" elemente in stiva"<<endl;}