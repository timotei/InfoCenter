#include<fstream.h>
int a[100][100],n;
int x[100],sol,k;
void afis()
{
 sol++;
 int i,j,z;
 z=1;

 for (i=1;i<k;i++)
  for (j=i+1;j<=k;j++)
  {
   a[j][i]=a[i][j]=x[z];
   z++;
  }
 for(i=1;i<=k;i++)
 {
  for (j=1;j<=k;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void gen(int i)
{
 for (int j=0;j<=1;j++)
 {
  x[i]=j;
  if (i==n) afis();
  else gen(i+1);
 }
}
void main()
{
 cout<<"Dati k: "; cin>>k;
 n=(k*(k-1)) /2;
 gen(1);
 cout<<"Solutii: "<<sol<<endl;
}