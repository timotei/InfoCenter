#include <iostream.h>
long getMaxNr(long nr)
{
 long nou=0;
 for (int i=9;i>=0;i--)
 {
  long aux=nr;
  while (aux)
  {
  if (aux%10==i) nou=nou*10+i;
  aux=aux/10;
  }
 }
return nou;
}
void main()
{
 long n;
 cin>>n;
 cout<<getMaxNr(n)<<endl;
}