#include<fstream.h>
int lab[20][20],sol[20][20],n,k,m,nr=0;
int di[]={0,0,1,0,-1};
int dj[]={0,1,0,-1,0};

void afish()
{for(int i=1;i<=n;i++)
   {for(int j=1;j<=m;j++)
       cout<<sol[i][j]<<" ";
   cout<<endl;
   }
cout<<endl<<endl;
}

void parcurs(int i,int j,int pas)
{int ii,jj,l;
for(l=1;l<=4;l++)
   {ii=i+di[l];
    jj=j+dj[l];
    if(lab[ii][jj]&&!sol[ii][jj])
       {sol[ii][jj]=pas;
       if(ii==1||ii==n||jj==1||jj==m)
			afish();
		 else  {
		 if(nr<=k)
		 parcurs(ii,jj,pas+1);}
       sol[ii][jj]=0;
       }
   }
}


void main()
{int x,y;
ifstream f("labirint.in");
cout<<"nou"<<endl;
f>>n>>m;
for(int i=1;i<=n;i++)
    for(int j=1;j<=m;j++)
	   f>>lab[i][j];
f>>x>>y;
f>>k;
sol[x][y]=1;
parcurs(x,y,2);
}