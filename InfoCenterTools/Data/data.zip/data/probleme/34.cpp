#include<fstream.h>
#include<conio.h>
struct nod{
 int nr;
 nod *urm;
};
void add(nod *&v, int nr)
{
nod *p=new nod;
p->nr=nr;
p->urm=v;
v=p;
}
void afis(nod *v)
{
 while (v)
 { cout<<v->nr<<" "; v=v->urm; }
 cout<<endl;
}
int isPrim(int nr)
{

 for (int i=2;i<=nr/2;i++)
  if (nr%i==0) return 0;
 return 1;
}
void add2(nod *&p, int nr)
{
nod *q=new nod;
q->nr=nr;
q->urm=p->urm;
p->urm=q;
}
void nrNeprime(nod *&v)
{
 nod *p=v;
 while (p)
 {
   if (!isPrim(p->nr))
   {
     int au=p->nr;
     for (int i=2;i<=p->nr/2;i++)
      if(isPrim(i) && (au%i==0))
      {
       do{
       au=au/i;
       add2(p,i);
       }
       while (au%i==0);
      }
   }
   p=p->urm;
 }
}
void main()
{
clrscr();
nod *v=NULL;
ifstream fin("date.ino");
int nr;
while (fin>>nr) add(v,nr);
cout<<"Stiva: "; afis(v);
nrNeprime(v);
cout<<"Stiva noua: "; afis(v);
fin.close();
}