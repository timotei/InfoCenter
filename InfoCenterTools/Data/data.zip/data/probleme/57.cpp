#include <fstream.h>
#include <conio.h>
#include <iomanip.h>

void creare(int a[100],int b[100],int &n)
	{
	 int i;
	 ifstream f("dt.in");
	 f>>n;
	 for (i=1;i<=n;i++)
		 f>>a[i]>>b[i];
	 f.close();
	}
void afis(int a[],int n)
	{
	 int i;
	 for(i=1;i<=n;i++)
		cout<<setw(5)<<a[i];
	 cout<<endl;
	}

void ord(int a[], int b[], int n)
	{
	 int i,j,aux;
	 for(i=1;i<n;i++)
		for(j=i+1;j<=n;j++)

			if (b[i]>b[j])
			{
			 aux=b[i];b[i]=b[j];b[j]=aux;
			 aux=a[i];a[i]=a[j];a[j]=aux;
			}
	}
void spect(int a[], int b[], int n)
	{
	 int i,u;
	 cout<<setw(5)<<a[1]<<setw(5)<<b[1]<<endl;
	 u=b[1];
	 for (i=2;i<=n;i++)
		if (a[i]>=u)
			{
			 cout<<setw(5)<<a[i]<<setw(5)<<b[i]<<endl;
			 u=b[i];
			}
	}

void main()
{
 int a[100],b[100],n;
 clrscr();
 creare(a,b,n);

 afis(a,n);
 afis(b,n);

 ord(a,b,n);
	 cout<<endl;

 afis(a,n);
 afis(b,n);

	 cout<<endl;
 spect(a,b,n);
}