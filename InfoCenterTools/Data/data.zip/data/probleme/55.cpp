#include<fstream.h>
#include<conio.h>
struct nod{
 int nr;
 nod *ant;
 nod *urm;
};
nod *v=NULL,*u=NULL;
//add la inceput
void add1()
{
 int nr;
 cout<<"Dati nr: "; cin>>nr;
 nod *p=new nod;
 p->nr=nr;
 if (!v) u=p;
 p->urm=v;
 v->ant=p;
 p->ant=NULL;
 v=p;
}
//add la final
void add2()
{
 int nr;
 cout<<"Dati nr: "; cin>>nr;
 nod *p=new nod;
 p->nr=nr;
 p->urm=NULL;
 p->ant=u;
 if(v==NULL) v=p;
 else u->urm=p;
 u=p;
}
//sterge de la inceput
void sterge1()
{
 nod *q=v;
 v=v->urm;
 v->ant=NULL;
 delete q;
}
//sterge ultimul
void sterge2()
{
 nod *p=u;
 u=u->ant;
 u->urm=NULL;
 delete p;
}
//sterge element
void stergeEl(int nr)
{
 for(nod *p=v;p;p=p->urm)
  if (nr==p->nr)
  {
   nod *q=p;
   if(p==v) sterge1();
   else
   {
     if (p==u) sterge2();
     else
     {
      p->urm->ant=p->ant;
      p->ant->urm=p->urm;
      p=p->urm;
      delete q;
     }
   }
  }
}
//afis de la inceput
void afis1()
{
  cout<<"Lista: ";
  for(nod *p=v;p;p=p->urm)
   cout<<p->nr<<" ";
  cout<<endl<<"Press any key... ";
  getch();
}
//afis de la coada
void afis2()
{
  cout<<"Lista: ";
  for(nod *p=u;p;p=p->ant)
   cout<<p->nr<<" ";
  cout<<endl<<"Press any key... ";
  getch();
}
void showSubMenu(char c)
{
  int opt=0;
  if (c=='x'||c=='X') return;
  switch(c){
    case 'A': case 'a':
    {
    while(opt!=1 && opt!=2)
    {
     cout<<" (1) Adaugare la inceput"<<endl;
     cout<<" (2) Adaugare la sfarsit"<<endl;
     cout<<" Optiune: "; cin>>opt;
     //TODO: exit
    }
     if(opt==1) add1();
     if(opt==2) add2();
     break;
    }
    case 'B': case 'b':
    {
    while(opt!=1 && opt!=2)
    {
     cout<<" (1) Afisare de la inceput"<<endl;
     cout<<" (2) Afisare de la sfarsit"<<endl;
     cout<<" Optiune: "; cin>>opt;
    }
     if(opt==1) afis1();
     if(opt==2) afis2();
     break;
    }
    case 'S': case 's':
    {
    while(opt!=1 && opt!=2 && opt!=3)
    {
     cout<<" (1) Stergere element"<<endl;
     cout<<" (2) Stergere prim element"<<endl;
     cout<<" (3) Stergere ultim element"<<endl;
     cout<<" Optiune: "; cin>>opt;
    }
     if(opt==1)
     {
      int n;
      cout<<"Dati element: "; cin>>n;
      stergeEl(n);
     }
     if(opt==2) sterge1();
     if(opt==3) sterge2();
     break;
    }
    default: break;
  }
}
void showMenu()
{
 char o='0';
 while(o!='x'&&o!='X')
 {
  clrscr();
  cout<<"Meniu:  "<<endl;
  cout<<"============="<<endl;
  cout<<"(A) Adaugare   "<<endl;
  cout<<"(B) Afisare   "<<endl;
  cout<<"(S) Stergere "<<endl;
  cout<<"(X) Iesire"<<endl;
  cout<<"=============="<<endl;
  cout<<"Optiune:"; cin>>o;
  showSubMenu(o);
  cout<<endl;
 }
}
void main()
{
 showMenu();
}