#include<fstream.h>
int a[100][100],n,m;
int sol[100],x,y;
void citire()
{
 int i,k,l;
 ifstream fin("graf1.in");
 fin>>n>>m;
 for (i=1;i<=m;i++)
 {
  fin>>k>>l;
  a[k][l]=a[l][k]=1;
 }
 fin.close();
}
void afisMat()
{
 cout<<"matrice adiacenta: "<<endl;
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void afis(int j)
{
 for (int i=1;i<=j;i++)
  cout<<sol[i]<<" ";
 cout<<endl;
}
int verif(int i)
{
 if (!a[sol[i-1]][sol[i]]) return 0;
 for (int z=1;z<i;z++)
   if (sol[z]==sol[i]) return 0;
 return 1;
}
void gen(int i)
{
 for (int j=1;j<=n;j++)
 {
  sol[i]=j;
  if (verif(i))
   if(j==y) afis(i);
   else if (i<n) gen(i+1);
 }
}
void main()
{
 citire();
 afisMat();
 cout<<"Dati x,y: "; cin>>x>>y;
 cout<<"Lanturile elementare: "<<endl;
 sol[1]=x;
 gen(2);
}