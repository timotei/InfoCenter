#include<fstream.h>

int a[100][100],n,m;
int viz[100];

void citire()
{
 int x,y,i;
 ifstream fin("graf.in");
 fin>>n>>m;
 for (i=1;i<=m;i++)
 {
  fin>>x>>y;
  a[x][y]=a[y][x]=1;
 }
 fin.close();
}
void afisMat()
{
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void dfs(int nod, int nrc)
{
 viz[nod]=nrc;
 for (int i=1;i<=n;i++)
  if (a[nod][i] &&!viz[i])
   dfs(i,nrc);
}
void main()
{
 citire();
 afisMat();
 int i,j,gr,grdpar=1;
 for (i=1;i<=n;i++)
 {
  gr=0;
  for (j=1;j<=n;j++)
   if (a[i][j]) gr+=1;
  if (gr%2!=0) { grdpar=0; break; }
 }
 if (grdpar)
 {
  int nrc=0;
  for (i=1;i<=n;i++)
   if (!viz[i])
   {
    nrc+=1;
    dfs(i,nrc);
   }
  if (nrc>1) cout<<"nu este graf eulerian."<<endl;
  else cout<<"este graf eulerian."<<endl;
 }
 else cout<<"nu este graf eulerian"<<endl;
}