#include <iostream.h>
#include <string.h>
void afis(char x[50], int n, int i)
{
 if(i<n) {cout<<x[i]; afis(x,n,i+1);}
}
void prefix(char x[50], int n)
{
if (n>=0)
 {
  afis(x,n,0);
  cout<<endl;
  prefix(x,n-1);
 }
}
void main()
{
 char a[50];
 cout<<"Dati cuvant: "; cin>>a;
 cout<<"Cuvantul este: "<<a<<endl;
 prefix(a,strlen(a));
}