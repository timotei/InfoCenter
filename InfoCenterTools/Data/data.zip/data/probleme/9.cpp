#include <iostream.h>
#include <conio.h>
void cit(long x[50], int n, int i)
{
 if(i<=n) {cin>>x[i]; cit(x,n,i+1);}
}
void afis(long x[50], int n, int i)
{
 if(i<=n) {cout<<x[i]<<" "; afis(x,n,i+1);}
}
void afisa(long x[50], int n)
{
if (n>0)
 {
  afis(x,n,1); cout<<endl;
  afisa(x,n-1);
 }
}
void afisInv(long x[50], int n, int i, int k)
{
 if (i>0 && k<=n) {cout<<x[i]<<" "; afisInv(x,n,i-1,k+1);}
}
void afisb(long x[50], int n, int i)
{
 if (n>0)
 {
  afisInv(x,n,i,1);
  cout<<endl;
  afisb(x,n-1,i);
 }
}
void main()
{
clrscr();
long x[50]={0};
int n;
cout<<"Dati n: "; cin>>n;
cout<<"Dati elem: "; cit(x,n,1);
cout<<"Elem sunt: "; afis(x,n,1); cout<<endl;
cout<<"a) "<<endl; afisa(x,n); cout<<endl;
cout<<"b) "<<endl; afisb(x,n,n);
}