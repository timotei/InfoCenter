#include <iostream.h>
int hasdivs(int a)
{
for (int i=2;i<=a/2;i++)
 if (a%i==0) return 0;
return 1;
}
long proddiv(long a)
{
 long prod=1;
 for (int i=2;i<=a/2;i++)
 if (a%i==0)
  {
	if (hasdivs(i)==1) prod=prod*i;
  }
return prod;
}
void main()
{
 long a,b;
 cout<<"Dati a: "; cin>>a;
 cout<<"Dati b: "; cin>>b;
 long k,l;
 cout<<"Prod Div-a: "<<proddiv(a)<<endl;
 cout<<"Prod Div-b: "<<proddiv(b)<<endl;
 if (proddiv(a) == proddiv(b))
  cout<<"DA"<<endl;
 else cout<<"NU"<<endl;
}