#include<iostream.h>
#include<math.h>
int n,x[100],nsol=0;
void afis()
{
 nsol++;
 cout<<endl;
 for (int i=1;i<=n;i++)
 {
  for(int j=1;j<=n;j++)
    if (x[i]==j) cout<<" "<<'R';
    else cout<<" *";
  cout<<endl;
 }
}
int verif(int i)
{
 int j;
 for (j=1;j<i;j++)
  if (x[j]==x[i]) return 0;

 for (j=1;j<i;j++)
  if (abs(x[j]-x[i])==abs(j-i)) return 0;
 return 1;
}
void gen(int i)       
{
 for (int j=1;j<=n;j++)
 {
  x[i]=j;
  if (verif(i))
    if(i==n) afis();
  else gen(i+1);
 }
}

int main()
{
 cout<<"Dati n: "; cin>>n;
 
 if (n>=64)
 {
 	cout<<"Ati specificat un numar prea mare de regin"<<endl;
 	return 0;
 }
 
 gen(1);
 cout<<"Sol: "<<nsol<<endl;
 return 0;
}