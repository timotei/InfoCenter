#include<iostream.h>
int sumadiv(int nr)
{ int s=0;
 for (int i=2;i<=nr/2;i++)
  if (nr%i==0) s=s+i;
 return s;
}
int prodiv(int nr)
{ int p=1;
 for (int i=2;i<=nr/2;i++)
  if (nr%i==0) p=p*i;
 return p;
}
void main()
{ int a,b,nr;
 cout<<"Dati a: "; cin>>a;
 cout<<"Dati b: "; cin>>b;
 for (int i=1;i<b;i++)
  for (int j=i+1;j<=b;j++)
   if (i!=j) if (sumadiv(i)==prodiv(j)) cout<<i<<"-"<<j<<endl;
 cout<<"Dati nr: "; cin>>nr;
 for (i=1;i<=nr;i++)
  if (sumadiv(i)==prodiv(i)) cout<<i<<" ";
 cout<<endl;
 for (i=1;i<=nr;i++)
  if (sumadiv(i)==i) cout<<i<<" ";
 cout<<endl;
}