#include<conio.h>
#include<fstream.h>
struct nod{ int nr; nod *urm;};
int nrElem(nod *v)
{
 if (v) return 1+nrElem(v->urm);
 return 0;
}
void add(nod *&v, nod *&v2,int nr)
{nod *p=new nod;
p->nr=nr; p->urm=NULL;
 if (v==NULL) v=p;
  else v2->urm=p;
 v2=p;
}
void afis(nod *v)
{ while (v)
    {cout<<v->nr<<" "; v=v->urm; }
    cout<<endl;
}
void add2(nod *&v, nod *&v2, int n)
{ nod *a=NULL;  int i=1;
 while (i<=n && v)
 {
  add(v2,a,v->nr); i++;
  v=v->urm;
 }
}
void main()
{
  nod *v=NULL,*vr=NULL,*v2=NULL;
    nod *v3=NULL,*p=NULL;
  ifstream fin("prim.in");
  int nr,ne;
  while (fin>>nr)
   add(v,vr,nr);
  fin.close();
  cout<<"Coada: "; afis(v);
  nr=nrElem(v);
  int b=(nr/3)+1; p=v;
  for(int i=1;i<b;i++)
   p=p->urm;
  //p -ultimul el din prima lista;
  v2=p->urm;
  p->urm=NULL;
  p=v2;
  for (i=1;i<b;i++) p=p->urm;
  v3=p->urm;
  p->urm=NULL;
  cout<<"1: "; afis(v);
  cout<<"2: "; afis(v2);
  cout<<"3: "; afis(v3);
}