#include<fstream.h>
double x[100];
double calcul(int st, int dr)
{
 if (st==dr) return x[st];
 else
 {
  int m=(st+dr)/2;
  int p1=calcul(st,m);
  int p2=calcul(m+1,dr);
  return p1*p2;
 }
}
void main()
{
 int i=1,n;
 ifstream fin("date.in");
 fin>>n;
 for(i=1;i<=n;i++)
  fin>>x[i];
 double p=calcul(1,n);
 cout<<"Prod: "<<p<<endl;
 fin.close();
}