#include<fstream.h>
#include<conio.h>
struct nod{
  int nr;
  nod *ant;
  nod *urm;
};
nod *u=NULL;
void add(nod *&v, int nr)
{
 nod *p=new nod;
 p->nr=nr;
 p->urm=NULL;
 p->ant=u;
 if(v==NULL) v=p;
 else u->urm=p;
 u=p;
}
void creare(nod *&v)
{
 ifstream fin("timo.in");
 int nr;
 while(fin>>nr) add(v,nr);
 fin.close();
}
void afis(nod *v)
{
  nod *p=v;
  cout<<"Lista 1: ";
  while(p) { cout<<p->nr<<" "; p=p->urm; }
  cout<<endl;
  cout<<"Lista 2: ";
  nod *q=u;
  while(q) { cout<<q->nr<<" "; q=q->ant; }
  cout<<endl;
}
int isPrim(int nr)
{
 for (int i=2;i<=nr/2;i++)
  if (nr%i==0) return 0;
 return 1;
}
void intrNr(nod *&v)
{
 cout<<"Nr neprime: ";
 nod *p=v;
 while(p)
 {
   if(!isPrim(p->nr))
   {
    cout<<p->nr<<" ";
    nod *q=new nod;
    q->nr=p->nr/2;
    q->ant=p;
    q->urm=p->urm;
    p->urm->ant=q;
    p->urm=q;
   }
   p=p->urm;
 }
 cout<<endl;
}
void main()
{
 clrscr();
 nod *v=NULL;
 creare(v);
 afis(v);
 intrNr(v);
 afis(v);
}