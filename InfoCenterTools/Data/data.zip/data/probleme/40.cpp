#include<fstream.h>
struct nod{
 int nr;
 nod *urm;
};
void add(nod *&v, int nr)
{
nod *p=new nod;
p->nr=nr;
p->urm=v;
v=p;
}
void creare(nod *&v)
{
 int nr;
 ifstream fin("dt.in");
 while (fin>>nr)
   add(v,nr);
 fin.close();
}
void afis(nod *v)
{
 while(v)
 { cout<<v->nr<<" "; v=v->urm;}
 cout<<endl;
}
void sterge(nod *&v)
{
 nod *p=v;
 v=v->urm->urm;
 delete p;
}
void eliminK(nod *&v, int k)
{
 nod *p=v;
 int i=1;
 while (p && (i<k-1)) { p=p->urm; i++; }

 nod *q=p->urm;
 cout<<"sters: "<<p->urm->nr<<endl;
 p->urm=p->urm->urm;
 delete q;
}
void main()
{
 cout<<endl<<endl;
 nod *v=NULL;
 int k=0;
 creare(v);
 cout<<"Stiva: "; afis(v);
 cout<<"Dati k: "; cin>>k;

 eliminK(v,k);
 cout<<"Stiva: "; afis(v);
}