#include<iostream.h>
#include<conio.h>
#include<stdlib.h>
struct nod{
int nr;
nod *urm;
};
void add(nod *&v, int a)
{
nod *p=new nod;
p->nr=a;
p->urm=v;
v=p;
}

void afis(nod *v)
{ cout<<"Stiva este: ";
while (v)
{cout<<v->nr<<" "; v=v->urm;}
cout<<endl;
}

int vrf(nod *v, int a)
{
 while (v)
 {
  if (v->nr==a) return 0;
  v=v->urm;
 }
 return 1;
}
int calcPuncte(nod *v)
{
 if (v) return v->nr+calcPuncte(v->urm);
 return 0;
}
 

void main()
{
 nod *v=NULL,*v2=NULL;
 int n=0,i=1;
 randomize();
 cout<<"Dati n: "; cin>>n;
 if (n%2!=0) { cout<<"Trebuia sa dati nr par."; return; }
 while (i<=n/2)
 {
  int rd;
  rd = random(n)+1;
  if (vrf(v,rd)) {add(v,rd); i++;}
 }
 i=1;
 while (i<=n/2)
 {
  int rd;
  rd = random(n)+1;
  if (vrf(v2,rd) && vrf(v,rd)) {add(v2,rd); i++;}
 }
 afis(v);
 afis(v2);
 if(calcPuncte(v)>calcPuncte(v2)) cout<<"primul este castigator"<<endl;
  else cout<<"Al doilea este castigator"<<endl;
}