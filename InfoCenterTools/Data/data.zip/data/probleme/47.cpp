#include<fstream.h>
#include<string.h>
#include<conio.h>
#include<iomanip.h>
struct nod{
  char n[30];
  double m;
  nod *urm;
};
void add(nod *&v, char n[], double m)
{
 nod *p=v;
 if (m==0)
 {
  while (strcmp(p->urm->n,n)<0) p=p->urm;
  nod *q=new nod;
  strcpy(q->n,n);
  q->m=m;
  q->urm=p->urm;
  p->urm=q;
 }
 else
 {
  while (m<p->urm->m && p->urm->urm!=NULL) p=p->urm;
  nod *q=new nod;
  strcpy(q->n,n);
  q->m=m;
  q->urm=p->urm;
  p->urm=q;
 }
}
void creare(nod *&v)
{
 ifstream fin("examen.in");
 nod *p=new nod; char n[30];

 v=new nod;
 v->urm=p;
 strcpy(p->n,"zzzzzzzzzz");
 p->urm=NULL;
 while (fin>>n) add(v,n,0);

 fin.close();
}
void afis(nod *v, int m)
{
 cout<<endl;
 for (nod *p=v->urm;p->urm!=NULL;p=p->urm)
  {
   cout<<setw(9)<<p->n;
   if (m) cout<<"| nota:"<<p->m;
   cout<<endl;
  }
 cout<<endl;
}
void addMedia(nod *&v,nod *&v2)
{
 v2=new nod; nod *q=new nod;
 v2->urm=q;
 q->m=9999999999;
 q->urm=NULL;
 double m;
 cout<<endl<<" Introduceti notele: "<<endl;
 for (nod *p=v->urm;p->urm!=NULL;p=p->urm)
  {
   cout<<p->n<<" nota:"; cin>>m;
   p->m=m;
   add(v2,p->n,p->m);
  }
 cout<<endl;
}
void main()
{
 clrscr();
 nod *v,*v2;
 creare(v);
 cout<<"Lista: "; afis(v,0);
 addMedia(v,v2);
 cout<<"\nLista: "; afis(v,1);
 //process(v);
 cout<<"Lista: "; afis(v2,1);
}