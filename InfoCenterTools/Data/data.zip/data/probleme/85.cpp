#include<iostream.h>
long x[100],s=0,cnt=0;

int verif(int i)
{
 for (int j=1;j<i;j++)
  if (x[j]==x[i]) return 0;
 return 1;
}
void adaug(int i)
{
 long nr=0;
 for (int j=i;j>0;j--)
  nr=nr*10+x[j];
 s=s+nr;
 cout<<"Nr: "<<nr<<" adaugat"<<endl;
 cnt++;
}
void gen(int i)
{
 for (int j=1;j<=9;j=j+2)
 {
  x[i]=j;
  if (verif(i))
    {adaug(i);
     if(i<5) gen(i+1);
     }
 }
}
void main()
{
 gen(1);
 cout<<"Suma("<<cnt<<"): "<<s<<endl;
}