#include<fstream.h>
int n,m,a[100][100];
int suc[100],pred[100],nrc;
void citire()
{
 ifstream fin("graf.in");
 fin>>n>>m;
 int x,y,i;
 for (i=1;i<=n;i++)
 {
  fin>>x>>y;
  a[x][y]=1;
 }
 fin.close();
}
void afisMat()
{
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void calc_suc(int vf)
{
 int k;
 suc[vf]=nrc;
 for (k=1;k<=n;k++)
  if (a[vf][k]==1 && !suc[k])
   calc_suc(k);
}
void calc_pred(int vf)
{
 int k;
 pred[vf]=nrc;
 for (k=1;k<=n;k++)
  if (a[k][vf]==1 && !pred[k])
   calc_pred(k);
}
void main()
{
 citire();
 afisMat();
 int i,j;
 nrc=1;
 for (i=1;i<=n;i++)
  if (!suc[i])
  {
   calc_suc(i);
   calc_pred(i);
   for (j=1;j<=n;j++)
    if (suc[j]!=pred[j]) suc[j]=pred[j]=0;
   nrc++;
  }
  cout<<"comp tari conexe: "<<endl;
  for(i=1;i<nrc;i++)
  {
   cout<<i<<": ";
   for (j=1;j<=n;j++)
    if (suc[j]==i) cout<<j<<" ";
   cout<<endl;
  }
}