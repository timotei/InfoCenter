#include<iostream.h>
int n,x[30];
int functie()
{ int aux=1, sum=0;
  for(int i=n;i>0;i--)
  { sum=aux*x[i]+sum;
    aux=aux*2;
  }
  return sum;  }

void afish(int n)
{ for(int i=1;i<=n;i++)
   { cout<<x[i]<<" ";
    }
    cout<<"  "<<functie();
    cout<<endl;
}


void gen(int i,int nz,int nu)
{if(nz>0&&i>1)
  {x[i]=0;
   if(i<n) gen(i+1,nz-1,nu);
    else afish(i);
  }
 if(nu>0)
  {x[i]=1;
   if(i<n)gen(i+1,nz,nu-1);
   else afish(i);}

}
void main()
{ int z;
cout<<"n=";cin>>z;
  int nz,nu;
 nz=nu=n=0;
 while(z!=0)
  { if(z%2==0) { nz++;
		cout<<"0";}
    else{nu++; cout<<"1";}
    z=z/2;
    n++;
  }
 cout<<endl;
 gen(1,nz,nu);
cout<<endl;
}