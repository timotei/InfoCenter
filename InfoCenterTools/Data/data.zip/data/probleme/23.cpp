#include<fstream.h>
#include<conio.h>
struct nod{
int nr;
nod *urm;
};
void add(nod *&v, nod*&n, int nr)
{
nod *p=new nod;
p->nr=nr;
p->urm=NULL;
if (v==NULL) v=p;
 else n->urm=p;
n=p;
}
void afis(nod *v)
{
 cout<<"Coada este: ";
 while (v)
 { cout<<v->nr<<" "; v=v->urm; };
 cout<<endl;
}
void afisNrPare(nod *v)
{
 cout<<"Nr pare: ";
 while (v)
 { if (v->nr%2==0) cout<<v->nr<<" ";
	v=v->urm;
 }
 cout<<endl;
}
void afisNrOrdPar(nod *v)
{
 cout<<"Nr de ord Par: ";
 v=v->urm;
 while (v)
 {
  cout<<v->nr<<" ";
  v=v->urm->urm;
 }
 cout<<endl;
}
void main()
{
clrscr();
nod *v=NULL,*n=NULL;
int nr;
ifstream fin("txt.txt");
while (fin>>nr)
 add(v,n,nr);
fin.close();
afis(v);
afisNrPare(v);
afisNrOrdPar(v);
}