#include<fstream.h>
int a[100][100],n,m;
int x[100],k;
void citire()
{
 int i,j,x,y,z;

 for (i=1;i<=n;i++)
  for (j=1;j<=n;j++)
   if (i!=j) a[i][j]=20000;

 ifstream fin("graf.in");
 fin>>n>>m;
 for (i=1;i<=n;i++)
 {
  fin>>x>>y>>z;
  a[x][y]=a[y][x]=z;
 }
 fin.close();
}
void afisMat()
{
 cout<<"matrice: "<<endl;
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
  if (a[i][j]!=20000)
   cout<<a[i][j]<<" ";
  else cout<<"x ";
  cout<<endl;
 }
 cout<<endl;
}
void afis()
{
 cout<<"ciclu: ";
 for (int i=1;i<=k;i++)
  cout<<x[i]<<" ";
 cout<<endl;
}
int verif(int i)
{
 int j,l;
 if (i==k && (x[1]!=x[i])) return 0;

 for (j=1;j<i-1;j++)
  for (l=j+1;l<i;l++)
   if (x[j]==x[l]) return 0;

 for (j=1;j<i;j++)
  if (a[x[j]][x[j+1]]==20000 || a[x[j]][x[j+1]]==0) return 0;

 return 1;
}
void gen(int i)
{
 for (int j=1;j<=n;j++)
 {
  x[i]=j;
  if (verif(i))
   if (i==k) afis();
   else gen(i+1);
 }
}
void main()
{
 citire();
 afisMat();
 cout<<"Dati k: "; cin>>k; k+=1;
 gen(1);
}