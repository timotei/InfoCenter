#include<fstream.h>
double x[100],k;
double apar(int st, int dr)
{
 if (st==dr)
  if (x[st]==k) return 1;
  else return 0;
 else
 {
  int m=(st+dr)/2;
  return apar(st,m)+apar(m+1,dr);
 }
}
void main()
{
 int i=1,n;
 double val;
 ifstream fin("date.in");
 fin>>n;
 for(i=1;i<=n;i++)
  fin>>x[i];
 cout<<"Dati valoare: "; cin>>k;
 cout<<"Val "<<k<<" apare de "<<apar(1,n)<<" ori."<<endl;
 fin.close();
}