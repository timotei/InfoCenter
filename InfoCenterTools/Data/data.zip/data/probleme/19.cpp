#include<iostream.h>
#include<stdlib.h>
#include<conio.h>
struct nod{
int nr;
int frec;
nod *urm;
};
 
int vrf(nod *v, int a)
{
 nod *p=v;
 while(p)
 { if(p->nr==a) { p->frec++ ; return 0; }
   p=p->urm;
 }
 return 1;
}
void adaug(nod *&v, int n)
{
nod *p=new nod;
p->nr=n;
p->urm=v;
p->frec=vrf(v,n);
v=p;
}
void afis(nod *v)
{
cout<<"Stiva este: ";
while (v) { cout<<v->nr<<" "; v=v->urm;}
cout<<endl;
}
void afisFrec(nod *v)
{
 nod *p=v;
 cout<<"Nr de frec:\n"<<"================="<<endl;
 while (p)
 {
  cout<<p->nr<<": "<<p->frec<<"|";
  p=p->urm;
 }
 cout<<endl;
}
 void main()
{
clrscr();
randomize();
nod *v=NULL;
int nr,rd;
cout<<"Dati nr: "; cin>>nr;
do{
 rd=random(nr)+1;
 cout<<rd<<" ";
 if (vrf(v,rd) && rd!=nr) adaug(v,rd);
}
while (rd!=nr);
afisFrec(v);
}