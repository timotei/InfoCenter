#include<fstream.h>
struct nod{
 int nr;
 nod *urm;
};
void add(nod *&v, int nr)
{
nod *p=new nod;
p->nr=nr;
p->urm=v;
v=p;
}
void creare(nod *&v)
{
 int nr;
 ifstream fin("date.in");
 while (fin>>nr)
   add(v,nr);
 fin.close();
}
void afis(nod *v)
{
 while(v)
 { cout<<v->nr<<" "; v=v->urm;}
 cout<<endl;
}
void add2(nod *&v, int n, int i)
{
 while (i>0)
 {
  nod *q=new nod;
  q->nr=n;
  q->urm=v->urm;
  v->urm=q;
  i--;
 }
}
void addPozImpare(nod *&v)
{
 nod *p=v;
 int i=1,k;
 while (p)
 {
  if (i%2!=0)
  {
   cout<<p->nr<<"="<<i<<endl;
   add2(p,p->nr,i);

   k=i+1;
   while (k>0) {p=p->urm; k--; }
  }
  else p=p->urm;
  i++;
 }
}
void main()
{
 cout<<endl;
 nod *v=NULL;
 creare(v);
 cout<<"Lista: "; afis(v);
 addPozImpare(v);
 cout<<"Lista: "; afis(v);
}