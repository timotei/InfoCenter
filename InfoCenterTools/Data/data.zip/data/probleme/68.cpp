#include<iostream.h>
double x[100],n;
double produs(int st, int dr)
{
if(st==dr){cout<<x[st]; return x[st];}
else {
cout<<"(";
	int mij=(st+dr)/2;
	double p1=produs(st,mij);
	cout<<"*";
	double p2=produs(mij+1,dr);
cout<<")";
	return p1*p2;
}
}
void main()
{
cout<<"dati n: ";cin>>n;
for(int i=1;i<=n;i++)
	cin>>x[i];
cout<<"= "<<produs(1,n)<<endl;
}