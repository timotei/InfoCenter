#include<fstream.h>
#include<iomanip.h>
int k,x[100],n;
int caut(int st, int dr)
{
 cout<<setw(2)<<st<<" |"<<setw(2)<<dr<<endl;
 if (st>dr) return -1;
 else
 {
  int m=(st+dr)/2;
  if (x[m]==k) return m;
  else
  {
   if (x[m]<k) return caut(m+1,dr);
   else return caut(st,m-1);
  }
 }
}
void main()
{
 ifstream fin("date.in");
 fin>>n;
 for (int i=1;i<=n;i++)
  fin>>x[i];
 cout<<"dati k: "; cin>>k;
 cout<<"ST | DR "<<endl;
 cout<<"nr: "<<caut(1,n)<<endl;
 fin.close();
}