#include<fstream.h>
#include<string.h>
int x[50],n,m,a[50];
char sir[500];
void afis()
{
 cout<<"f(x) | ";
 for (int i=0;i<n;i++)
  cout<<sir[x[i]]<<" ";
 cout<<endl;
}
void gen(int i)
{
 for (int j=0;j<m;j++)
 {
  x[i]=j;
  if (i==n) afis();
  else gen(i+1);
 }
}
void main()
{
 cout<<"Dati n: "; cin>>n;
 cout<<"Dati cuvant: "; cin>>sir;

 cout<<" x   |";
 for (int i=1;i<=n;i++) cout<<" "<<i;
 cout<<endl<<"---------------------------------------"<<endl;
 m=strlen(sir);
 gen(1);
}