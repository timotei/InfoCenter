#include<fstream.h>
int n,m,sol[20][20],x,y,a[20][20],sol2[20][20];
int di[]={0,-2,-1,1,2,2,1,-1,-2};
int dj[]={0,1,2,2,1,-1,-2,-2,-1};
int min[20][20],minp=32000,minp2=32000,min2[20][20];

void gen2(int i, int j, int pas);

void afish()
{
/* for(int i=1;i<=n;i++)
 {
	for(int j=1;j<=m;j++)
		cout<<sol[i][j]<<"   ";
	cout<<endl;
 }
 cout<<endl;*/

 if(minp>sol[n][m])
 {
  minp=sol[n][m];
  for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
		min[i][j]=sol[i][j];
	sol2[n][m]=1;
	gen2(n,m,2);
 }
}

void afish2()
{
/* for(int i=1;i<=n;i++)
 {
	for(int j=1;j<=m;j++)
		cout<<sol2[i][j]<<"   ";
	cout<<endl;
 }
 cout<<endl;*/
 if(minp2>sol2[1][1])
 {
  minp2=sol2[1][1];
  for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
		min2[i][j]=sol2[i][j];

 }
}

void gen2(int i,int j,int pas)
{
 int ii,jj,k;
 for(k=1;k<=8;k++)
 {
	ii=i+di[k];
	jj=j+dj[k];
	if(ii>0&&ii<=n&&jj>0&&jj<=m&&!sol2[ii][jj]&&!a[ii][jj])
	{
		sol2[ii][jj]=pas;
		if(ii==1&&jj==1)
			afish2();
		else
			gen2(ii,jj,pas+1);
		sol2[ii][jj]=0;
	}

 }
}

void gen(int i,int j,int pas)
{
 int ii,jj,k;
 for(k=1;k<=8;k++)
 {
	ii=i+di[k];
	jj=j+dj[k];
	if(ii>0&&ii<=n&&jj>0&&jj<=m&&!sol[ii][jj])
	{
		sol[ii][jj]=pas;
		a[ii][jj]=1;
		if(ii==n&&jj==m)
			afish();
		else
			gen(ii,jj,pas+1);
		sol[ii][jj]=0;
	}

 }
}

void main()
{
 int I,j;
 ifstream f("date2.in");
 f>>n>>m;
 sol[1][1]=1;
 gen(1,1,2);

 cout<<"drum minim"<<endl;
  for(i=1;i<=n;i++)
  {
	for(j=1;j<=m;j++)
		cout<<min[i][j]<<"  ";
	cout<<endl;
  }

  cout<<endl;
 for(i=1;i<=n;i++)
  {
	for(j=1;j<=m;j++)
		cout<<min2[i][j]<<"  ";
	cout<<endl;
  }
}