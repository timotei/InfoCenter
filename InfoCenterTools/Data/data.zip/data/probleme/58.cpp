#include<fstream.h>
double x[100];
double max(int st, int dr)
{
 if (st==dr) return x[st];
 else
 {
  int m=(st+dr)/2;
  int m1=max(st,m);
  int m2=max(m+1,dr);
  if (m1>m2) return m1;
  else return m2;
 }
}
void main()
{
 int i=1,n;
 ifstream fin("date.in");
 fin>>n;
 for(i=1;i<=n;i++)
  fin>>x[i];
 double p=max(1,n);
 cout<<"Max: "<<p<<endl;
 fin.close();
}