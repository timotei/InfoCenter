#include<fstream.h>
int ph[20][20],sol[20][20];
int n,m;
int di[] = {0,1,-1,0, 0,1,-1,-1, 1},
    dj[] = {0,0, 0,1,-1,1,-1, 1,-1};
ofstream fout("photo.out");
void afis(int pas)
{
 fout<<"Obiect: "<<pas<<endl;
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=m;j++)
   if (sol[i][j]==pas)
    fout<<sol[i][j]<<" ";
   else fout<<"0 ";
  fout<<endl;
 }
 fout<<endl;
}
void caut(int i,int j, int pas)
{
 int k,ii,jj;
 for (k=1;k<=8;k++)
 {
  ii=i+di[k];
  jj=j+dj[k];
  if (ph[ii][jj] && !sol[ii][jj])
  {
   sol[ii][jj]=pas;
   caut(ii,jj,pas);
  }
 }
}
void main()
{
 int pas,i,j;
 ifstream fin("photo.in");
 fin>>n>>m;
 for (i=1;i<=n;i++)
  for (j=1;j<=m;j++)
   fin>>ph[i][j];
 pas=0;

 for (i=1;i<=n;i++)
  for (j=1;j<=m;j++)
   if (ph[i][j] && !sol[i][j])
   {
    pas++;
    caut(i,j,pas);
    afis(pas);
   }
  cout<<"Obiecte: "<<pas<<endl;
}