#include<fstream.h>
#include<iomanip.h>
int sah[20][20],sol[20][20],min[20][20];
int n,m,sl,mins=20000;
int x,y,a,b;
int di[] = {0,-2,-1, 1, 2, 2, 1,-1,-2 },
    dj[] = {0, 1, 2, 2, 1,-1,-2,-2,-1 };
ofstream fout("cal.out");
void afis(int pas)
{
 sl++;
 for(int i=1;i<=n;i++)
 {
  for (int j=1;j<=m;j++)
   fout<<setw(2)<<sol[i][j]<<" ";
  fout<<endl;
 }
 fout<<endl;
 if (pas<mins)
 {
  mins=pas;
  for(int i=1;i<=n;i++)
  {
  for (int j=1;j<=m;j++)
   min[i][j]=sol[i][j];
 }
 }
}
void parcurge(int i,int j, int pas)
{
 int k,ii,jj;
 for(k=1;k<=8;k++)
 {
  ii=i+di[k];
  jj=j+dj[k];
  if ((ii<=n && jj<=m && ii>=1 && jj>=1) && !sol[ii][jj])
  {
   sol[ii][jj]=pas;
   if (ii==a && jj==b) afis(pas);
   else parcurge(ii,jj,pas+1);

   sol[ii][jj]=0;
  }
 }
}
void main()
{
 cout<<"Dati n,m: "; cin>>n>>m;
 cout<<"Dati x,y(pornire): "; cin>>x>>y;
 cout<<"Dati a,b(destinatie): "; cin>>a>>b;
 sol[x][y]=1;
 parcurge(x,y,2);
 fout<<"Sol: "<<sl<<endl;
 cout<<"Minim: "<<mins<<endl;
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=m;j++)
   cout<<setw(2)<<min[i][j];
  cout<<endl;
 }
 cout<<endl;
}