#include<iostream.h>
#include<conio.h>
long n,k,x[100];
void afis()
{
 int cnt=0;
 for (int j=1;j<=n;j++)
  if (x[j]==1) cnt++;
 if(cnt==k)
 {
  for(int i=1;i<=n;i++)
   cout<<x[i];
  cout<<" ";
 }
}
int verif(int i)
{
 if (i==1&&x[i]==0) return 0;
 return 1;
}
void gen(int i)
{
 for (int j=0;j<=9;j++)
 {
  x[i]=j;
  if (verif(i))
   if (i==n) afis();
   else gen(i+1);
 }
}
void main()
{
 clrscr();
 cout<<"Dati n: "; cin>>n;
 cout<<"Dati k: "; cin>>k;
 gen(1);
}