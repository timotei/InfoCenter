#include<fstream.h>
#include<iomanip.h>
int sah[20][20],sol[20][20];
int n,nm,sl;
int di[] = {0,-2,-1, 1, 2, 2, 1,-1,-2 },
    dj[] = {0, 1, 2, 2, 1,-1,-2,-2,-1 };
ofstream fout("cal.out");
void afis()
{
 sl++;
 for(int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   fout<<setw(2)<<sol[i][j]<<" ";
  fout<<endl;
 }
 fout<<endl;
}
void parcurge(int i,int j, int pas)
{
 int k,ii,jj;
 for(k=1;k<=8;k++)
 {
  ii=i+di[k];
  jj=j+dj[k];
  if ((ii<=n && jj<=n && ii>=1 && jj>=1) && !sol[ii][jj])
  {
   sol[ii][jj]=pas;
   if (pas==nm) afis();
   else parcurge(ii,jj,pas+1);

   sol[ii][jj]=0;
  }
 }
}
void main()
{
 cout<<"Dati n: "; cin>>n;
 nm=n*n;
 sol[1][1]=1;
 parcurge(1,1,2);
 cout<<"Sol: "<<sl<<endl;
}