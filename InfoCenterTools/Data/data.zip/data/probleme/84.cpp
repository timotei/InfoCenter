#include <iostream.h>
int x[20],n;

int verif(int i)
{
 if(i>1&&x[i-1]<x[i]) return 0;
 return 1;
}
void afis()
{
 for(int j=1;j<=n;j++)
  cout<<x[j];
 cout<<"  ";
}
void gen(int i)
{
 for(int j=8;j>=0;j-=2)
  {if(i>1) x[i]=j;
	  else if(j>=2) x[i]=j;

	if(verif(i)) if(i==n) afis();
	  else gen(i+1);
}
}
void main()
{
 cin>>n;
 gen(1);
}