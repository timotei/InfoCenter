#include<iostream.h>
#include<conio.h>
#include<stdio.h>
	      // alb galb port rosu verde albastru
int culori[7]={0, 15, 14,  22,  4,    2,    1 };
int st=0;
char x[7]={0};

void afis()
{
 for (int i=1;i<4;i++)
  {
   textcolor(culori[x[i]]);
   cprintf("%c",(char)219);
  }
 cout<<"   "; st++;
 if (st==13) { cout<<endl<<endl; st=0; }
}
int verif(int i)
{
 if (i>1 && x[i]==x[i-1]) return 0;
 if (i==2 && x[i]>3) return 0;
 return 1;
}
void drapelcl(int i)
{
 int j;
 for (j=1;j<7;j++)
 {
  x[i]=j;
  if (verif(i))
   if (i==3) afis();
   else drapelcl(i+1);
  }
}
void main()
{
 clrscr();
 drapelcl(1);
}