#include<fstream.h>
int a[100][100],n,m;
int viz[100];
void citire()
{
 ifstream fin("graf.in");
 fin>>n>>m;
 int x,y;
 for (int i=1;i<=m;i++)
 {
  fin>>x>>y;
  a[x][y]=a[y][x]=1;
 }
 fin.close();
}
void afis()
{
 for (int i=1;i<=n;i++)
 {
  for (int j=1;j<=n;j++)
   cout<<a[i][j]<<" ";
  cout<<endl;
 }
 cout<<endl;
}
void parc(int i)
{
 cout<<i<<" ";
 viz[i]=1;
 for (int j=1;j<=n;j++)
  if (a[i][j] && !viz[j])
    parc(j);
}
void main()
{
 citire();
 afis();
 cout<<"Grafuri: "; parc(1);

}