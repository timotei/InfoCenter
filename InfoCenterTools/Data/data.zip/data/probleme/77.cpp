#include<iostream.h>
int x[100],k,n;
void afis()
{
 for (int i=1;i<=n;i++)
  cout<<x[i]<<" ";
 cout<<endl;
}
int verif(int i)
{
 for(int j=1;j<i;j++)
  if (x[i]==x[j]) return 0;

 if (i>1)
 {
  if (i<k) if (x[i-1]<x[i]) return 0;
  if (i>k) if (x[i-1]>x[i]) return 0;
 }
 return 1;
}
void gen(int i)
{
 for (int j=1;j<=n;j++)
 {
  x[i]=j;
  if(verif(i))
     if (i==n) afis();
      else gen(i+1);
 }
}
void main()
{
 cout<<"Dati n: "; cin>>n;
 cout<<"Dati k: "; cin>>k;
 for (int i=1;i<=n;i++)
  x[i]=i;
 gen(1);
}