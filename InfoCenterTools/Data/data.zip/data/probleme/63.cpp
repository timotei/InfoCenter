#include<fstream.h>
int x[100],n;
int suma(int st, int dr)
{
 if (st==dr)
 {
  if (x[st]%2==0) return x[st];
   else return 0;
 }
 else
 {
   int m=(st+dr)/2;
   int s1=suma(st,m);
   int s2=suma(m+1,dr);
   return s1+s2;
 }
}
void main()
{
 ifstream fin("date.in");
 fin>>n;
 for (int i=1;i<=n;i++)
  fin>>x[i];
 fin.close();
 cout<<"Suma: "<<suma(1,n)<<endl;
}